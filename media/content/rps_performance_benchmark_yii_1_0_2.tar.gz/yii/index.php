<?php
   // include Yii bootstrap file
   require_once('./yii-1.0.2.r614/framework/yii.php');

   // create a Web application instance and run
   Yii::createWebApplication()->run();
?>
