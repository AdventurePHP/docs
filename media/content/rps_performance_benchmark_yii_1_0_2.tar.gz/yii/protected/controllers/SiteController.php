<?php
class SiteController extends CController
{
        public function actionIndex(){
                die(file_get_contents('/var/www/html/yii/content.txt'));
                //die('Hello world! (yii)');
                //echo 'Hello world! (yii)';
        }
}
?>
