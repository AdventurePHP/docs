<?php
   /**
   *  @package sites::apfdocupage::biz::actions::setmodel
   *  @class SetModelInput
   *
   *  Represents the action's input object.
   *
   *  @author Christian Achatz
   *  @version
   *  Version 0.1, 22.08.2008<br />
   */
   class SetModelInput extends FrontcontrollerInput
   {

      function SetModelInput(){
      }

    // end class
   }
?>