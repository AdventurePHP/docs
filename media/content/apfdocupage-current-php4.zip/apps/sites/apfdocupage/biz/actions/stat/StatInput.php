<?php
   /**
   *  @package sites::apfdocupage::biz::actions::stat
   *  @class StatInput
   *
   *  Represents the action's input object.
   *
   *  @author Christian Achatz
   *  @version
   *  Version 0.1, 14.10.2008<br />
   */
   class StatInput extends FrontcontrollerInput
   {

      function StatInput(){
      }

    // end class
   }
?>