<?php
   /**
   *  @package modules::socialbookmark::biz::actions
   *  @class ShowImageInput
   *
   *  Implementierung des FrontcontrollerInputs f�r das Socialbookmark-Modul.<br />
   *
   *  @author Christian W. Sch�fer
   *  @version
   *  Version 0.1, 07.09.2007<br />
   */
   class ShowImageInput extends FrontcontrollerInput
   {

      function ShowImageInput(){
      }

    // end class
   }
?>