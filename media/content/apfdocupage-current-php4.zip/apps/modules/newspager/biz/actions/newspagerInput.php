<?php
   /**
   *  @package modules::newspager::biz
   *  @class newspagerInput
   *
   *  Front controller input class.<br />
   *
   *  @author Christian Achatz
   *  @version
   *  Version 0.1, 02.20.2008<br />
   */
   class newspagerInput extends FrontcontrollerInput
   {

      function newspagerInput(){
      }

    // end class
   }
?>