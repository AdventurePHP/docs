<?php
   class ShowCaptchaImageInput extends FrontcontrollerInput
   {

      function ShowCaptchaImageInput(){
      }

    // end class
   }
?>