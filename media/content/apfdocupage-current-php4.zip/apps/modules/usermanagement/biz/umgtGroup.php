<?php
   import('modules::usermanagement::biz','umgtBase');


   /**
   *  @package modules::usermanagement::biz
   *  @module umgtGroup
   *
   *  Domain object for user.<br />
   *
   *  @author Christian Achatz
   *  @version
   *  Version 0.1, 26.04.2008<br />
   */
   class umgtGroup extends umgtBase
   {

      var $__Users = array();

      function umgtGroup(){
      }

    // end class
   }
?>