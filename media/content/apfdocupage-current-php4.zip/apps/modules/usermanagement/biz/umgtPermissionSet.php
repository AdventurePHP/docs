<?php
   import('modules::usermanagement::biz','umgtBase');


   /**
   *  @package modules::usermanagement::biz
   *  @module umgtPermissionSet
   *
   *  Domain object for user.<br />
   *
   *  @author Christian Achatz
   *  @version
   *  Version 0.1, 26.04.2008<br />
   */
   class umgtPermissionSet extends umgtBase
   {

      var $__Permissions = array();


      function umgtPermissionSet(){
      }


      function getPermissionByKey($Key){
         return $Value;
       // end function
      }

    // end class
   }
?>