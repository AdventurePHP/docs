<?php
   import('modules::usermanagement::biz','umgtBase');


   /**
   *  @package modules::usermanagement::biz
   *  @module umgtPermission
   *
   *  Domain object for user.<br />
   *
   *  @author Christian Achatz
   *  @version
   *  Version 0.1, 26.04.2008<br />
   */
   class umgtPermission extends umgtBase
   {

      var $__Key;
      var $__Value;


      function umgtPermission(){
      }

    // end class
   }
?>