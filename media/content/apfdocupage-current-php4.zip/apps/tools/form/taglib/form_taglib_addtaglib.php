<?php
   /**
   *  @package tools::form::taglib
   *  @class form_taglib_addtaglib
   *
   *  Implements the &lt;form:addtaglib /&gt; tag.
   *
   *  @author Christian Achatz
   *  @version
   *  Version 0.1, 11.07.2008<br />
   */
   class form_taglib_addtaglib extends core_taglib_addtaglib
   {

      function form_taglib_addtaglib(){
      }

    // end class
   }
?>