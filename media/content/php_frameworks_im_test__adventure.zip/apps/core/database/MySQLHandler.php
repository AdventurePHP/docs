<?php
   import('core::logging','Logger');

   register_shutdown_function('mysqlTerminateConnection');

   /**
   *  @package core::database
   *  @module mysqlTerminateConnection()
   *
   *  Wrapper-Funktion zum Schlie�en einer DB-Verbindung.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 01.04.2007<br />
   */
   function mysqlTerminateConnection(){
      $SQL = &Singleton::getInstance('MySQLHandler');
      $SQL->closeConnection();
    // end function
   }


   /**
   *  @package core::database
   *  @module MySQLHandler
   *
   *  Dienst zur Abstraktion einer MySQL-Datenbank. Beinhaltet<br />
   *  keine Caching-Mechanismen.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 21.06.2004<br />
   *  Version 0.2, 06.04.2005<br />
   *  Version 0.3, 22.01.2006<br />
   *  Version 0.4, 06.02.2006 (Konfiguration 'ZeigeFehler' bereinigt)<br />
   *  Version 0.5, 16.04.2006 (Bereinigung alter Methoden, Quell-Code-Dokumentation)<br />
   *  Version 0.6, 29.03.2007 (Auf neuen Logger umgestellt)<br />
   *  Version 0.7, 01.04.2007 (Performance-Tuning: Connect/Disconnect wird nun nur noch EIN Mal ausgef�hrt)<br />
   */
   class MySQLHandler extends coreObject
   {

      /**
      *  @private
      *  Verbindungs-Kennung.
      */
      var $__dbConnection = null;


      /**
      *  @private
      *  LastInsertID.
      */
      var $__Last_Insert_ID;


      /**
      *  @private
      *  Anzahl der selektierten Ergebnisse.
      */
      var $__NumRows;


      /**
      *  @private
      *  Datenbank-Host.
      */
      var $__db_host;


      /**
      *  @private
      *  Datenbank-Benutzer.
      */
      var $__db_user;


      /**
      *  @private
      *  Datenbank-Password.
      */
      var $__db_pass;


      /**
      *  @private
      *  Datenbank-Name.
      */
      var $__db_name;


      /**
      *  @private
      *  Log-Datei (Instanz des Loggers).
      */
      var $__dbLog;


      /**
      *  @private
      *  Log-Datei-Name.
      */
      var $__dbLogFileName = 'mysql';


      /**
      *  @private
      *  Debug-Mode an?
      */
      var $__db_debug;


      /**
      *  @private
      *  Zeigt an, ob Klasse bereits initialisiert wurde.
      */
      var $__isInitialized = false;


      function MySQLHandler(){
      }


      /**
      *  @module __initMySQLHandler()
      *  @private
      *
      *  Initialisiert den MySQLHandler, falls dies noch nicht geschehen ist.<br />
      *  Methode ist ein interner Helper, da von aussen nur der Context gesetzt wird, und die<br />
      *  restliche Initialisierung m�glichst nicht von Aussen erledigt werden sollte.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 28.03.2007<br />
      *  Version 0.2, 01.04.2007 (Connect wird beim INIT erledigt)<br />
      */
      function __initMySQLHandler(){

         // Falls noch nicht initialisiert wurde initialisieren
         if($this->__isInitialized == false){

            // Konfiguration auslesen
            $Config = &$this->__getConfiguration('core::database','connections');

            // Section auslesen
            $Section = $Config->getSection('MySQL');

            // Pr�fen, ob Section existent
            if($Config == null){
               trigger_error('[MySQLHandler->__initMySQLHandler()] Configuration "dbconnectiondaten" in namspace "core::database" and context "'.$this->__Context.'" contains no valid data!',E_USER_ERROR);
               exit();
             // end if
            }

            // Zugangsdaten auslesen
            $this->__db_host = $Section['DB.Host'];
            $this->__db_user = $Section['DB.User'];
            $this->__db_pass = $Section['DB.Pass'];
            $this->__db_name = $Section['DB.Name'];

            // Debug-Mode aktivieren / deaktivieren
            if(isset($Section['DB.DebugMode'])){
               if($Section['DB.DebugMode'] == 'true' || $Section['DB.DebugMode'] == '1'){
                  $this->__db_debug_mode = true;
                // end if
               }
               else{
                  $this->__db_debug_mode = false;
                // end else
               }

             // end if
            }
            else{
               $this->__db_debug_mode = false;
             // end else
            }

            // Logdatei festlegen (Instanz des Logger's)
            $this->__dbLog = &Singleton::getInstance('Logger');

            // Klasse als initialisiert kennzeichnen
            $this->__isInitialized = true;

            // Zur DB verbinden
            $this->__connect();

          // end if
         }

       // end function
      }


      /**
      *  @module __connect()
      *  @private
      *
      *  Erledigt Datenbankconnect und Standard-Datenbank-Auswahl.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, ???<br />
      *  Version 0.2, ???<br />
      *  Version 0.3, 2002<br />
      *  Version 0.4, 10.04.2004<br />
      *  Version 0.5, 04.12.2005<br />
      *  Version 0.6, 24.12.2005<br />
      *  Version 0.7, 04.01.2005<br />
      */
      function __connect(){

         $this->__dbConnection = @mysql_connect($this->__db_host,$this->__db_user,$this->__db_pass);

         if(!is_resource($this->__dbConnection)){
            trigger_error('[MySQLHandler->__connect()] Database connection could\'t be established ('.mysql_errno().': '.mysql_error().')!',E_USER_ERROR);
            exit();
          // end if
         }

         $result = @mysql_select_db($this->__db_name,$this->__dbConnection);

         if(!$result){
            trigger_error('[MySQLHandler->__connect()] Database could note selected ('.mysql_errno().': '.mysql_error().')!',E_USER_ERROR);
            exit();
          // end if
         }

       // end function
      }


      /**
      *  @module __close()
      *  @private
      *
      *  Trennt die durch __verbindeDatenbank() aufgebaute MySQL-Verbindung.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 2002<br />
      *  Version 0.2, 10.04.2004<br />
      *  Version 0.3, 04.12.2005<br />
      *  Version 0.4, 24.12.2005<br />
      */
      function __close(){

         $result = @mysql_close($this->__dbConnection);
         $this->__dbConnection = null;

         if(!$result){
            trigger_error('[MySQLHandler->__close()] An error occured during closing of the database connection ('.mysql_errno().': '.mysql_error().')!',E_USER_WARNING);
          // end if
         }

       // end function
      }


      /**
      *  @module closeConnection()
      *  @public
      *
      *  �ffentliche Funktion zum Trennen der DB-Verbindung (f�r shutdown function).<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 01.04.2007<br />
      *  Version 0.2, 01.04.2007 (Verbindung wird nur dan geschlossen, wenn auch vorhanden)<br />
      */
      function closeConnection(){

         // Verbindung schlie�en, falls diese besteht
         if($this->__dbConnection != null){
            $this->__close();
          // end if
         }

       // end function
      }


      /**
      *  @module executeStatement()
      *  @public
      *
      *  F�hrt ein Statement in einem Namespace aus. Platzhalter werden<br />
      *  durch die in $Variablen gegebenen Werte ersetzt.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 24.12.2005<br />
      *  Version 0.2, 16.01.2006<br />
      *  Version 0.3, 19.01.2006<br />
      *  Version 0.4, 23.04.2006 (�nderung auf Grund des ApplicationManagers)<br />
      *  Version 0.5, 05.08.2006 (Dateiendung muss beim Stmt-File nicht mehr angegeben werden; Es m�ssen nicht zwingend Parameter angegeben werden)<br />
      *  Version 0.6, 05.08.2006 (optionalen Parameter $ShowStatement hinzugef�gt)<br />
      *  Version 0.7, 29.03.2007 (An neue Implementierung f�r PC V2 angepasst)<br />
      */
      function executeStatement($Namespace,$StatementFile,$Params = array(),$ShowStatement = false){

         // Initialisiere Klasse
         $this->__initMySQLHandler();


         // Dateinamen generieren und pr�fen, ob Datei existiert
         $File = APPS__PATH.'/config/'.str_replace('::','/',$Namespace).'/'.str_replace('::','/',$this->__Context).'/statements/'.APPS__ENVIRONMENT.'_'.$StatementFile.'.sql';

         if(!file_exists($File)){
            trigger_error('[MySQLHandler->executeStatement()] There\'s no statement file with name "'.(APPS__ENVIRONMENT.'_'.$StatementFile.'.sql').'" for given namespace "'.$Namespace.'" and current context "'.$this->__Context.'"!');
            exit();
          // end if
         }

         // Statement einlesen
         $Statement = file_get_contents($File);


         // Platzhalter ersetzen
         if(count($Params) > 0){

            foreach($Params as $Key => $Value){
               $Statement = str_replace('['.$Key.']',$Value,$Statement);
             // end foreach
            }

          // end if
         }


         // Statement ausgeben
         if($ShowStatement == true){
            trigger_error($Statement);
          // end if
         }


         // Statement ausf�hren
         $result = @mysql_query($Statement);


         // Fehler tracken
         $mysql_error = mysql_error();
         $mysql_errno = mysql_errno();

         if(!empty($mysql_error) || !empty($mysql_errno)){

            // Meldung generieren
            $Message = '('.$mysql_errno.') '.$mysql_error.' (Statement: '.$Statement.')';

            // Meldung protokollieren
            $this->__dbLog->logEntry($this->__dbLogFileName,$Message,'ERROR');

            // Fehler werfen
            if($this->__db_debug_mode == '1'){
               trigger_error('[MySQLHandler->executeStatement()] '.$Message);
             // end if
            }

          // end if
         }


         // $__Last_Insert_ID setzen
         $ID = @mysql_fetch_assoc(@mysql_query('SELECT Last_Insert_ID() AS Last_Insert_ID;'));
         $this->__Last_Insert_ID = $ID['Last_Insert_ID'];


         // Ergebnis zur�ckgeben
         return $result;

       // end function
      }


      /**
      *  @module fetchData()
      *  @public
      *
      *  Holt einen Datensatz, der aus einem ResultSet stammt aus der Datenbank ab.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 24.12.2005<br />
      */
      function fetchData($ResultCursor){

         // Initialisiere Klasse
         $this->__initMySQLHandler();

         // Daten abholen
         $data = mysql_fetch_assoc($ResultCursor);

         // Daten zur�ckgeben
         return $data;

       // end function
      }


      /**
      *  @module setDataPointer()
      *  @public
      *
      *  Setzt den Result-Pointer auf eine durch $offset angegebenen Ergebnis-Zeile.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 15.01.2006<br />
      */
      function setDataPointer($result,$offset){

         // Initialisiere Klasse
         $this->__initMySQLHandler();

         // Pointer auf Daten-Set setzen
         @mysql_data_seek($result,$offset);

       // end function
      }


      /**
      *  @module getAffectedRows()
      *  @public
      *
      *  Liefert die Anzahl der durch ein Statement betroffene Datens�tze.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 04.01.2006<br />
      */
      function getAffectedRows($Result){

         // Initialisiere Klasse
         $this->__initMySQLHandler();

         // Affected Rows zur�ckgeben
         return mysql_affected_rows($Result);

       // end function
      }


      /**
      *  @module getLastID()
      *  @public
      *
      *  Liefert die ID des zuletzt eingef�gten Datensatzes (Nummer des Primary Keys).<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 04.01.2006<br />
      */
      function getLastID(){

         // Initialisiere Klasse
         $this->__initMySQLHandler();

         // LastInsertID zur�ckgeben
         return $this->__Last_Insert_ID;

       // end function
      }


      /**
      *  @module getNumRows()
      *  @public
      *
      *  Liefert die ID des zuletzt eingef�gten Datensatzes (Nummer des Primary Keys).<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 04.01.2006<br />
      */
      function getNumRows($Result){

         // Initialisiere Klasse
         $this->__initMySQLHandler();

         // NumRows zur�ckgeben
         return mysql_num_rows($Result);

       // end function
      }


      /**
      *  @module executeTextStatement()
      *  @public
      *
      *  F�hrt ein Statement, das via String �bergeben wurde aus.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 22.01.2006<br />
      */
      function executeTextStatement($Statement){

         // Initialisiere Klasse
         $this->__initMySQLHandler();


         // Statement ausf�hren
         $Result = @mysql_query($Statement);


         // Fehler tracken
         $mysql_error = mysql_error();
         $mysql_errno = mysql_errno();


         if(!empty($mysql_error) || !empty($mysql_errno)){

            // Meldung generieren
            $Meldung = '('.mysql_errno().') '.mysql_error().' (Statement: '.$Statement.')';

            // Fehler protokollieren
            $this->__dbLog->logEntry($this->__dbLogFileName,$Meldung,'ERROR');

            if($this->__db_debug_mode == '1'){
               trigger_error('[MySQLHandler->executeTextStatement()] '.$Meldung);
             // end if
            }

          // end if
         }


         // $__Last_Insert_ID setzen
         $ID = @mysql_fetch_assoc(@mysql_query('SELECT Last_Insert_ID() AS Last_Insert_ID'));
         $this->__Last_Insert_ID = $ID['Last_Insert_ID'];


         // Ergebnis zur�ckgeben
         return $Result;

       // end function
      }


      /**
      *  @module getServerInfo()
      *  @public
      *
      *  Gibt die Version des Datenbank-Servers zur�ck.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 05.03.2006<br />
      */
      function getServerInfo(){

         // Initialisiere Klasse
         $this->__initMySQLHandler();

         // Version ziehen
         $Version = mysql_get_server_info();

         // Daten zur�ckgeben
         return $Version;

       // end function
      }


      /**
      *  @module getDatabaseName()
      *  @public
      *
      *  Gibt den Namen der Datenbank zur�ck.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 05.03.2006<br />
      */
      function getDatabaseName(){

         // Initialisiere Klasse
         $this->__initMySQLHandler();

         // DB-Name zur�ckgeben
         return $this->__db_name;

       // end function
      }


      /**
      *  @module backupDatabase()
      *  @public
      *
      *  Erzeugt einen Dump der aktuellen Datenbank mit dem CLI-Tool 'mysqldump'.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 01.07.2006<br />
      *  Version 0.2, 18.08.2006 (Standard-Namen wurde von db_host auf db_name ge�ndert)<br />
      */
      function backupDatabase($File = ''){

         // Initialisiere Klasse
         $this->__initMySQLHandler();

         // Dump-File benennen
         if(empty($File)){
            $File = 'dump_'.($this->__db_name).'_'.date('Y_m_d__H_i_s').'.sql';
          // end if
         }

         // mysqldump ausf�hren
         exec('mysqldump --add-drop-table --complete-insert --create-options --extended-insert --force --lock-tables --host='.($this->__db_host).' --user='.($this->__db_user).' --password='.($this->__db_pass).' '.($this->__db_name).' > '.$File);

         // true zur�ckgeben
         return true;

       // end function
      }


      /**
      *  @module backupDatabase()
      *  @public
      *
      *  Spielt ein Datenbank-Backup wieder ein, das zuvor mit backupDatabase() erzeugt wurde.<br />
      *  Benutzt das CLI-Tool 'mysql'.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 01.07.2006<br />
      */
      function restoreDatabase($File = ''){

         // Initialisiere Klasse
         $this->__initMySQLHandler();

         // Pr�fen, ob Dump-Datei existiert
         if(!file_exists($File)){
            return false;
          // end if
         }

         // Import ausf�hren
         exec('mysql --host='.($this->__db_host).' --user='.($this->__db_user).' --password='.($this->__db_pass).' --database='.($this->__db_name).' --force --xml --execute="source '.$File.'"');

         // true zur�ckgeben
         return true;

       // end function
      }

    // end class
   }
?>