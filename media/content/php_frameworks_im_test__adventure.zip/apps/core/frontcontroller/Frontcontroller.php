<?php
   import('core::pagecontroller','pagecontroller');


   /**
   *  @package core::frontcontroller
   *  @module AbstractFrontcontrollerAction
   *  @abstract
   *
   *  Implementiert das Action-Interface f�r eine Frontcontroller-Action.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 27.01.2007<br />
   *  Version 0.2, 24.02.2007 (Parameter "KeepInURL" hinzugef�gt)<br />
   */
   class AbstractFrontcontrollerAction extends coreObject
   {

      /**
      *  @private
      *  Namespace der Action.
      */
      var $__ActionNamespace;


      /**
      *  @private
      *  Name der Action.
      */
      var $__ActionName;


      /**
      *  @private
      *  Input-Objekt der Action.
      */
      var $__Input;


      /**
      *  @private
      *  Speichert den Typ der Action. M�gliche Werte: pre | post.
      *  Standard ist pre.
      */
      var $__Type = 'pre';


      /**
      *  @private
      *  Speichert, ob die Action in der URL beibehalten werden soll. Werte: true | false.
      */
      var $__KeepInURL = null;


      function AbstractFrontcontrollerAction(){
      }


      /**
      *  @module getInput()
      *  @public
      *
      *  Liefert das Input-Objekt (Model) zur�ck.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 05.02.2007<br />
      */
      function &getInput(){
         return $this->__Input;
       // end function
      }


      /**
      *  @module run()
      *  @abstract
      *
      *  Abstrakte Methode, die vom FrontController zum Ausf�hren einer Action aufgerufen wird.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 27.01.2007<br />
      */
      function run(){
      }

    // end class
   }


   /**
   *  @package core::frontcontroller
   *  @module AbstractFrontcontrollerInput
   *
   *  Implementiert das Input-Interface f�r einen Frontcontroller-Input.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 27.01.2007<br />
   */
   class FrontcontrollerInput extends coreObject
   {

      function FrontcontrollerInput(){
      }


      /**
      *  @module getAttributesAsString()
      *  @public
      *
      *  Gibt die Input-Attribute als URL-formatierten String zur�ck.<br />
      *
      *  @return string $AttributesString; URL-formatierten Attribut-String
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 10.02.2007<br />
      */
      function getAttributesAsString($URLRewriting = APPS__URL_REWRITING){

         // Parameter vom Frontcontroller auslesen
         $Action = & $this->__ParentObject;
         $fC = &$Action->getByReference('ParentObject');


         // URL-Trenner setzen
         if($URLRewriting == true){
            $InputDelimiter = $fC->get('URLRewritingInputDelimiter');
            $KeyValueDelimiter = $fC->get('URLRewritingKeyValueDelimiter');
          // end if
         }
         else{
            $InputDelimiter = $fC->get('InputDelimiter');
            $KeyValueDelimiter = $fC->get('KeyValueDelimiter');
          // end else
         }


         // Return-Array initialisieren
         $AttributesArray = (string)'';


         // Array f�llen
         if(count($this->__Attributes) > 0){

            foreach($this->__Attributes as $Key => $Value){
               $AttributesArray[] = $Key.$KeyValueDelimiter.$Value;
             // end if
            }

          // end if
         }


         // String zur�ckgeben
         return implode($InputDelimiter,$AttributesArray);

       // end function
      }

    // end class
   }


   /**
   *  @package core::frontcontroller
   *  @module Frontcontroller
   *
   *  Implementiert den Frontcontroller.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 27.01.2007<br />
   *  Version 0.2, 01.03.2007 (Input-Objekte werden nun vom Frontcontroller geladen!)<br />
   *  Version 0.3, 08.06.2007 (Gr��erer Umbau zu den PermanentActions und der URL-Filterung)<br />
   *  Version 0.4, 01.07.2007 (__createInputObject() entfernt)<br />
   */
   class Frontcontroller extends coreObject
   {

      /**
      *  @private
      *  Enth�lt die registrierten Actions.
      */
      var $__Actions = array();


      /**
      *  @private
      *  Action-Keyword.
      */
      var $__ActionKeyword = 'action';


      /**
      *  @private
      *  Trenner innerhalb des Namespaces einer Action.
      */
      var $__NamespaceURLDelimiter = '_';


      /**
      *  @private
      *  Trenner zwischen Namespace und Action-Keyword.
      */
      var $__NamespaceKeywordDelimiter = '-';


      /**
      *  @private
      *  Trenner zwischen Action-Keyword und Action-Klasse.
      */
      var $__KeywordClassDelimiter = ':';


      /**
      *  @private
      *  Trenner zwischen Action-Keyword und Action-Klasse bei aktiviertem URLRewriting..
      */
      var $__URLRewritingKeywordClassDelimiter = '/';


      /**
      *  @private
      *  Trenner zwischen Input-Werten.
      */
      var $__InputDelimiter = '|';


      /**
      *  @private
      *  Trenner zwischen Input-Werten bei aktiviertem URLRewriting.
      */
      var $__URLRewritingInputDelimiter = '/';


      /**
      *  @private
      *  Trenner zwischen Key zu Value eines Input-Wertes.
      */
      var $__KeyValueDelimiter = ':';


      /**
      *  @private
      *  Trenner zwischen Key zu Value eines Input-Wertes bei aktiviertem URLRewriting.
      */
      var $__URLRewritingKeyValueDelimiter = '/';


      /**
      *  @private
      *  Namespace des Frontcontrollers.
      */
      var $__Namespace = 'core::frontcontroller';


      function Frontcontroller(){
      }


      /**
      *  @module start()
      *  @public
      *
      *  Startet den Frontcontroller
      *
      *  @param string $Namespace; Namespace des Templates
      *  @param string $Template; Name des Templates
      *  @param bool $RewriteLink; Anzeige, ob URL-Rewriting aktiviert ist
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 20.01.2007<br />
      *  Version 0.2, 27.01.2007<br />
      *  Version 0.3, 31.01.2007 (Context-Behandlung hinzugef�gt)<br />
      *  Version 0.4, 03.02.2007 (Permanente Actions hinzugef�gt)<br />
      *  Version 0.5, 08.06.2007 (URL-Filtering in generische Filter ausgelagert)<br />
      *  Version 0.6, 01.07.2007 (Ausf�hrung von permanentpre und permanentpost gel�scht)<br />
      */
      function start($Namespace,$Template,$RewriteLink = APPS__URL_REWRITING){

         // Pr�fen ob ein Context gesetzt ist
         if(empty($this->__Context)){
            $this->__Context = $Namespace;
          // end if
         }


         // URI-Filter initialisieren
         if($RewriteLink == true){
            $fCRF = filterFactory::getFilter('core::filter','frontcontrollerRewriteRequestFilter');
          // end if
         }
         else{
            $fCRF = filterFactory::getFilter('core::filter','frontcontrollerRequestFilter');
          // end if
         }


         // URI filtern und Actions parsen
         $fCRF->filter();


         // Seite instanziieren
         $Page = new Page();


         // Context setzen
         $Page->set('Context',$this->__Context);


         // Sprache setzen
         $Page->set('Language',$this->__Language);


         // Initiales Design laden
         $Page->loadDesign($Namespace,$Template);


         // Actions vor dem Transformieren aufrufen
         $this->__runActions('pre');


         // Seite transformieren
         $PageContent = $Page->transform();


         // Actions nach dem Transformieren aufrufen
         $this->__runActions('post');


         // Inhalt der Seite ausgeben
         echo $PageContent;

       // end function
      }


      /**
      *  @module getActionByName()
      *  @public
      *
      *  Gibt die Referenz auf eine Actions zur�ck.<br />
      *
      *  @param string $ActionName; Name der Action
      *  @return object $Action | bool NULL; Die Action oder null
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 05.02.2007<br />
      *  Version 0.2, 08.02.2007 (Noch nicht geladene Actions werden lazy nachgeladen und zur�ckgeliefert)<br />
      *  Version 0.3, 11.02.2007 (ActioName ist nun der Name der Section, bzw. des Alias der Action)<br />
      *  Version 0.4, 01.03.2007 (Input-Objekte werden nun vom Frontcontroller geladen!)<br />
      *  Version 0.5, 01.03.2007 (Pr�fung ob Action-Klasse vorhanden ist hinzugef�gt!)<br />
      *  Version 0.6, 08.03.2007 (Auf neuen configurationManager umgestellt)<br />
      *  Version 0.7, 08.06.2007 (Automatisches Neuerstellen einer Action entfernt)<br />
      */
      function &getActionByName($ActionName){

         // Actions-Array durchiterieren
         for($i = 0; $i < count($this->__Actions); $i++){

            // Pr�fen, ob Action mit dem �bergebenen Namen existiert
            if($this->__Actions[$i]->get('ActionName') == $ActionName){
               return $this->__Actions[$i];
             // end if
            }

          // end for
         }

         // Falls Action nicht vorhanden, NULL zur�ckgeben
         $null = null;
         return $null;

       // end function
      }


      /**
      *  @module getActions()
      *  @public
      *
      *  Gibt die Referenz auf eine Actions zur�ck.<br />
      *
      *  @return array $Actions; Array mit Action-Objekten
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 05.02.2007<br />
      */
      function &getActions(){
         return $this->__Actions;
       // end function
      }


      /**
      *  @module __getActionNamespaceByURLString()
      *  @private
      *
      *  Erzeugt aus einem URL-Namespace einen regul�ren Namespace.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 03.06.2007<br />
      */
      function __getActionNamespaceByURLString($NamespaceString){
         return str_replace($this->__NamespaceURLDelimiter,'::',$NamespaceString);
       // end function
      }


      /**
      *  @module registerAction()
      *  @public
      *
      *  Registriert eine Action beim FC und l�d die Parameter des Models aus einem Config-File.<br />
      *  Erwartet eine Konfigurationsdatei mit Namen {APPS__ENVIRONMENT}_actionsconfig.ini unter<br />
      *  dem Pfad {$ActionNamespace}::actions::{$this->__Context}.<br />
      *
      *  @param string $ActionNamespace; Namespace der Action
      *  @param string $ActionName; Name der Action
      *  @param array $ActionParams; (Input-)Parameter der Action
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.06.2007<br />
      *  Version 0.2, 01.07.2007 (ActionNamespace wird nun zentral in addAction() �bersetzt)<br />
      *  Version 0.3, 01.07.2007 (Parsen der Config-Parameter wird nun korrekt durchgef�hrt)<br />
      */
      function registerAction($ActionNamespace,$ActionName,$ActionParams = array()){

         // Config f�r Input laden
         $Config = &$this->__getConfiguration($ActionNamespace.'::actions','actionconfig');

         if($Config != null){

            // Parameter-Wert-Strings trennen
            if(strlen(trim($Config->getValue($ActionName,'FC.InputParams'))) > 0){

               // Parameter trennen
               $Params = explode($this->__InputDelimiter,$Config->getValue($ActionName,'FC.InputParams'));

               for($i = 0; $i < count($Params); $i++){

                  // Parameter und Wert trennen
                  if(substr_count($Params[$i],$this->__KeyValueDelimiter) > 0){

                     $ParamValuePair = explode($this->__KeyValueDelimiter,$Params[$i]);

                     // Paar zu den ActionParams hinzuf�gen
                     if(isset($ParamValuePair[0]) && isset($ParamValuePair[1])){
                        $ActionParams = array_merge($ActionParams,array($ParamValuePair[0] => $ParamValuePair[1]));
                      // end if
                     }

                   // end if
                  }

                // end for
               }

             // end if
            }

          // end if
         }

         // Action hinzuf�gen
         $this->addAction($ActionNamespace,$ActionName,$ActionParams);

       // end function
      }



      /**
      *  @module addAction()
      *  @public
      *
      *  F�gt eine Action hinzu. Erwartet eine Konfigurationsdatei mit Namen <br />
      *  {APPS__ENVIRONMENT}_actionsconfig.ini unter dem Pfad {$ActionNamespace}::actions::{$this->__Context}.<br />
      *
      *  @param string $ActionNamespace; Namespace der Action
      *  @param string $ActionName; Name der Action
      *  @param array $ActionParams; (Input-)Parameter der Action
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 05.06.2007<br />
      *  Version 0.2, 01.07.2007 (Action-Konfiguration wird nun auch unter "{Namespace}::actions::{Context}" erwartet)<br />
      */
      function addAction($ActionNamespace,$ActionName,$ActionParams = array()){

         // Namespace umwandeln
         $ActionNamespace = $this->__getActionNamespaceByURLString($ActionNamespace);
         $ActionNamespace .= '::actions';

         // Action-Config laden
         $CfgObj = &$this->__getConfiguration($ActionNamespace,'actionconfig');


         // Pr�fen ob Konfiguration existent ist
         if($CfgObj == null){
            trigger_error('[Frontcontroller::__parseActions()] No configuration available for namespace "'.$ActionNamespace.'" and context "'.$this->__Context.'"!',E_USER_ERROR);
            exit;
          // end if
         }


         // Configuration auslesen
         $ActionSection = $CfgObj->getSection($ActionName);

         if($ActionSection == null){
            trigger_error('[Frontcontroller::__parseActions()] No config section for action key "'.$ActionName.'" available!',E_USER_ERROR);
            exit;
          // end if
         }


         // Action importieren
         import($ActionSection['FC.ActionNamespace'],$ActionSection['FC.ActionFile']);


         // Action importieren
         import($ActionSection['FC.ActionNamespace'],$ActionSection['FC.InputFile']);


         // Pr�fen, ob Action-Klasse vorhanden ist
         if(!class_exists($ActionSection['FC.ActionClass'])){
            trigger_error('[Frontcontroller::__parseActions()] Action class with name "'.$ActionSection['FC.ActionClass'].'" could not be found. Please check your action configuration file!',E_USER_ERROR);
            exit;
          // end if
         }


         // Action initialisieren
         $Action = new $ActionSection['FC.ActionClass'];


         // ActionNamen bekannt machen
         $Action->set('ActionNamespace',$ActionNamespace);


         // ActionNamen bekannt machen
         $Action->set('ActionName',$ActionName);


         // Context �bergeben
         $Action->set('Context',$this->__Context);


         // Sprache �bergeben
         $Action->set('Language',$this->__Language);


         // Input Objekt erzeugen
         $Input = new $ActionSection['FC.InputClass'];


         // Input-Attribute aus URL parsen
         $Input->setAttributes($ActionParams);


         // Action bekannt machen
         $Input->setByReference('ParentObject',$Action);
         $Action->set('Input',$Input);


         // Frontcontroller bekannt machen
         $Action->setByReference('ParentObject',$this);


         // Action in Action-Array einsetzen
         $this->__Actions[] = $Action;

       // end function
      }


      /**
      *  @module __runActions()
      *  @private
      *
      *  F�hrt diejenigen Actions aus, die dem �bergebenen Typ entsprechen.<br />
      *
      *  @param string $Type; Typ der Action (pre | post)
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 27.01.2007<br />
      *  Version 0.2, 31.01.2007 (Debug-Ausgaben konfigurierbar gemacht)<br />
      *  Version 0.3, 03.02.2007 (Actions werden nun gebenchmarked)<br />
      *  Version 0.4, 01.07.2007 (Debug-Ausgaben entfernt)<br />
      */
      function __runActions($Type = 'pre'){

         // BenchmarkTimer holen
         $T = &Singleton::getInstance('benchmarkTimer');


         // Actions ausf�hren
         for($i = 0; $i < count($this->__Actions); $i++){

            // Action ausf�hren, wenn Typ passt
            if($this->__Actions[$i]->get('Type') == $Type){

               // Timer starten
               $T->start(get_class($this->__Actions[$i]).'::run()');


               // Action ausf�hren
               $this->__Actions[$i]->run();


               // Timer stoppen
               $T->stop(get_class($this->__Actions[$i]).'::run()');

             // end if
            }

          // end for
         }

       // end function
      }

    // end class
   }
?>