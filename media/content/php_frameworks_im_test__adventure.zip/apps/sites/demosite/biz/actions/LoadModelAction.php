<?php
   import('tools::link','frontcontrollerLinkHandler');
   import('sites::demosite::biz::actions','DemositeModel');


   class LoadModelAction extends AbstractFrontcontrollerAction
   {

      function LoadModelAction(){
         $this->__KeepInURL = true;
       // end function
      }


      function run(){

         //
         // Rewrite URLS
         //
         //$URL = 'http://dev.adventure-php-framework.org/Seite/ChangeLog/~/sites_demosite_biz-action/LoadModel/test/test/test2/test2/~/benchmarkreport/true/test/1234/test2/5678';
         //$URL = 'http://dev.adventure-php-framework.org/Seite/ChangeLog/benchmarkreport/true/param1/value1/param2/value2';
         //$URL = 'http://dev.adventure-php-framework.org/sites_demosite_biz-action/LoadModel/test/test/test2/test2/';
         //$URL = 'http://dev.adventure-php-framework.org/Seite/ChangeLog/~/sites_demosite_biz-action/LoadModel/test/test/test2/test2/~/benchmarkreport/true/test/1234/test2/5678/~/modules_guestbook_biz-action/LoadEntryList/pagesize/10/pager/false/adminview/false';

         //
         // Normale URLS
         //
         //$URL = 'http://dev.adventure-php-framework.org/?Seite=ChangeLog&sites_demosite_biz-action:LoadModel=test:test|test2:test2&benchmarkreport=true&test=1234&test2=5678';
         $URL = 'http://dev.adventure-php-framework.org/?Seite=ChangeLog&benchmarkreport=true&param1=value1&param2=value2';
         //$URL = 'http://dev.adventure-php-framework.org/?sites_demosite_biz-action:LoadModel=test:test|test2:test2';


         $ChangeParams = array(
                               'modules_guestbook_biz-action:LoadEntryList' => 'pagesize:20|pager:false|adminview:true',
                               'Seite' => 'Guestbook'
                               );

         echo frontcontrollerLinkHandler::generateLink($URL,$ChangeParams,false);

       // end function
      }

    // end class
   }
?>