<?php
   class DemositeModel extends FrontcontrollerInput
   {

      function DemositeModel(){
      }

    // end class
   }
?>