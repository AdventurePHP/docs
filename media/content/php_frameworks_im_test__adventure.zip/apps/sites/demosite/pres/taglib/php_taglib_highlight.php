<?php
   /**
   *  @package sites::demosite::pres::taglib
   *  @module php_taglib_highlight
   *
   *  Implementiert die Tag-Library f�r das PHP-Code-Highlightning.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 08.04.2007<br />
   */
   class php_taglib_highlight extends Document
   {

      function php_taglib_highlight(){
      }


      /**
      *  @module transform()
      *  @public
      *
      *  Implementiert die Interface-Methode "transform()", mit dem ein Objekt in HTML transformiert wird.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.04.2007<br />
      *  Version 0.2, 05.05.2007 (PHP-Tags werden nun nicht mehr mit ausgegeben)<br />
      *  Version 0.3, 01.07.2007 (Probleme mit verschobenen Quelltexten behoben. Klasse "div.phpcode" wird zur Formatierung verwendet)<br />
      */
      function transform(){

         // Quelltext highlighten
         // - Zeilenumbr�che am Anfang entfernen
         // - Leerzeichen und Zeilenumbr�che am Ende entfernen
         // - Leerzeichen und Zeilenumbr�che um den kompletten Text entfernen
         $HighlightedContent = highlight_string(trim('<?php '.ltrim(rtrim($this->__Content),"\x0A..\x0D").' ?>'),true);

         // PHP-Anfangstag ersetzen
         $HighlightedContent = str_replace('<font color="#007700">&lt;?</font>','',$HighlightedContent);
         $HighlightedContent = str_replace('<font color="#0000BB">&lt;?php&nbsp;','<font color="#0000BB">',$HighlightedContent);
         $HighlightedContent = str_replace('<font color="#0000BB">php','<font color="#0000BB">',$HighlightedContent);
         $HighlightedContent = str_replace('<font color="#0000BB">&nbsp;</font>','',$HighlightedContent);

         // PHP-Endtag ersetzen
         $HighlightedContent = str_replace('<font color="#0000BB">?&gt;</font>','',$HighlightedContent);

         // Code im DIV zur�ckgeben
         return '<div class="phpcode">'.$HighlightedContent.'</div>';

       // end function
      }

    // end class
   }
?>