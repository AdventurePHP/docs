<?php
   /**
   *  @package sites::demosite::pres::taglib
   *  @module doku_taglib_link
   *
   *  Implementiert die Tag-Library f�r das erzeugen eines HTML-Links f�r die Dokumentation.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 15.08.2007<br />
   */
   class doku_taglib_link extends Document
   {

      /**
      *  @private
      *  Maximale L�nge des Links, ab dem gek�rzt wird.
      */
      var $__MaxLinkLength = 50;


      function doku_taglib_link(){
      }


      /**
      *  @module transform()
      *  @public
      *
      *  Implementiert die Interface-Methode "transform()", mit dem ein Objekt in HTML transformiert wird.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 15.08.2007<br />
      */
      function transform(){

         // Content von Leerzeichen befreien
         $Content = trim($this->__Content);

         // R�ckgabe initialisieren
         $Link = (string)'';

         // Pr�fen, ob Content gef�llt ist
         if(strlen($Content) > 0){

            // Link-Tag hinzuf�gen
            $Link .= '<a ';

            // Link hinzuf�gen
            $Link .= 'href="'.trim($this->__Content).'" ';

            // Title hinzuf�gen
            $Link .= 'title="'.trim($this->__Content).'" ';

            // Target hinzuf�gen
            if(isset($this->__Attributes['target'])){
               $Link .= 'target="'.$this->__Attributes['target'].'" ';
             // end if
            }
            else{
               $Link .= 'target="_blank" ';
             // end else
            }

            // CSS-Klasse hinzuf�gen
            if(isset($this->__Attributes['class'])){
               $Link .= 'class="'.$this->__Attributes['class'].'" ';
             // end if
            }

            // CSS-Style hinzuf�gen
            if(isset($this->__Attributes['style'])){
               $Link .= 'style="'.$this->__Attributes['style'].'" ';
             // end if
            }

            // Linkrewrite-Protection hinzuf�gen
            $Link .= 'linkrewrite="false"';

            // Link-Attribute schlie�en
            $Link .= '>';

            // Link-Text hinzuf�gen:
            // Verhalten wie bei z.B. PHPBB. Links ab einer gewissen L�nge werden abgek�rzt
            // und mit {Teil1}..{10 Zeichen des Endes} dargestellt werden.
            if(strlen($Content) > $this->__MaxLinkLength){
               $Link .= substr($Content,0,$this->__MaxLinkLength - 20).'...'.substr($Content,strlen($Content) - 10 ,10);
             // end if
            }
            else{
               $Link .= $Content;
             // end else
            }

            // Link abschlie�en
            $Link .= '</a>';

          // end if
         }


         // Link zur�ckgeben
         return $Link;

       // end function
      }

    // end class
   }
?>