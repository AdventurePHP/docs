<?php
   import('core::filesystem','filesystemHandler');


   /**
   *  @package sites::demosite::pres::documentcontroller
   *  @module releases_v1_controller
   *
   *  Implementiert den DocumentController f�r das Design 'releases.html'. Zeigt die<br />
   *  Releases des Frameworks an.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 16.08.2007<br />
   */
   class releases_v1_controller extends baseController
   {

      /**
      *  @private
      *  Definiert den Pfad, in dem die Releases liegen.
      */
      var $__ReleasesFolder = './frontend/media/releases';


      function releases_v1_controller(){
      }


      /**
      *  @module transformContent
      *  @public
      *
      *  Implementiert die abstrakte Methode "transformContent".<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 16.08.2007<br />
      *  Version 0.2, 18.08.2007 (Release-Dateien werden nun sortiert ausgegeben)<br />
      */
      function transformContent(){

         // Buffer initialisieren
         $Buffer_Releases = (string)'';

         // Releases auslesen und aufsteigend sortieren
         if(!is_dir($this->__ReleasesFolder)){
            $Template__NoContent = &$this->__getTemplate('NoContent');
            $this->setPlaceHolder('Content',$Template__NoContent->transformTemplate());
            return true;
          // end if
         }

         // FilesystemHandler instanziieren und Verzeichnis auslesen
         $fH = new filesystemHandler($this->__ReleasesFolder);
         $Releases = array_reverse($fH->showDirContent());

         // Releases ausgeben
         if(count($Releases) > 0){

            // Referenzen auf die Templates holen
            $Template__ReleaseHead = &$this->__getTemplate('ReleaseHead');
            $Template__ReleaseFile = &$this->__getTemplate('ReleaseFile');

            for($i = 0; $i < count($Releases); $i++){

               // Release-Nummer f�llen
               $Template__ReleaseHead->setPlaceHolder('ReleaseNumber',$Releases[$i]);

               // Dateien holen
               $fH->changeWorkDir($this->__ReleasesFolder.'/'.$Releases[$i].'/download');
               $Files = $fH->showDirContent();

               // Dateien sortieren
               sort($Files);

               // ReleaseDescription f�llen
               $ReleaseDescriptionFile = $this->__ReleasesFolder.'/'.$Releases[$i].'/release_description.html';
               if(file_exists($ReleaseDescriptionFile)){
                  $Template__ReleaseHead->setPlaceHolder('ReleaseDescription',file_get_contents($ReleaseDescriptionFile));
                // end if
               }
               else{
                  $Template__ReleaseDescriptionPlaceHolder = &$this->__getTemplate('ReleaseDescriptionPlaceHolder');
                  $Template__ReleaseHead->setPlaceHolder('ReleaseDescription',$Template__ReleaseDescriptionPlaceHolder->transformTemplate());
                // end else
               }

               // Documentation f�llen
               $Template__Documentation = &$this->__getTemplate('Documentation');
               $Template__Documentation->setPlaceHolder('ReleaseVersion',$Releases[$i]);
               $Template__ReleaseHead->setPlaceHolder('Documentation',$Template__Documentation->transformTemplate());

               // Buffer initialisieren
               $Buffer_Files = (string)'';

               // Dateien ausgeben
               for($j = 0; $j < count($Files); $j++){

                  // Datei-Attribute lesen
                  $FileAttributes = $fH->showFileAttributes($this->__ReleasesFolder.'/'.$Releases[$i].'/download/'.$Files[$j]);

                  //Template f�llen
                  $Template__ReleaseFile->setPlaceHolder('Link','/frontend/media/releases/'.$Releases[$i].'/download/'.$Files[$j]);
                  $Template__ReleaseFile->setPlaceHolder('Name',$Files[$j]);
                  $Template__ReleaseFile->setPlaceHolder('Date',$FileAttributes['ModifyingDate']);
                  $Template__ReleaseFile->setPlaceHolder('Size',$fH->showFileSize($this->__ReleasesFolder.'/'.$Releases[$i].'/download/'.$Files[$j]));
                  $Template__ReleaseFile->setPlaceHolder('Type',$FileAttributes['Extension']);

                  // Datei zum Puffer hinzuf�gen
                  $Buffer_Files .= $Template__ReleaseFile->transformTemplate();

                // end for
               }

               // Datei-Liste in Release einsetzen
               $Template__ReleaseHead->setPlaceHolder('ReleaseFiles',$Buffer_Files);

               // Release generieren
               $Buffer_Releases .= $Template__ReleaseHead->transformTemplate();

             // end for
            }

          // end if
         }

         // Buffer in Inhalt einsetzen
         $this->setPlaceHolder('Content',$Buffer_Releases);

       // end function
      }

    // end class
   }
?>