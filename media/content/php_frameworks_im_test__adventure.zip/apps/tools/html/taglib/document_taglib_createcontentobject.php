<?php
   import('tools::variablen','variablenHandler');


   /**
   *  @package tools::html::taglib
   *  @module document_taglib_createContentObject
   *
   *  Implementiert die TagLib f�r den Tag "<document:createcontentobject />".<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 04.01.2006<br />
   */
   class document_taglib_createcontentobject extends Document
   {

      /**
      *  @module document_taglib_createcontentobject()
      *  @public
      *
      *  Konstruktor der Klasse. Ruft den Konstruktor der Eltern-Klasse auf.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 04.01.2006<br />
      */
      function document_taglib_createcontentobject(){
         parent::Document();
       // end function
      }


      /**
      *  @module onParseTime()
      *  @public
      *
      *  Implementiert die abstrakte Methode onParseTime().<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 04.01.2006<br />
      */
      function onParseTime(){

         // Attribute auslesen
         $RequestParameter = $this->__Attributes['requestparam'];
         $DefaultValue = $this->__Attributes['defaultvalue'];

         // Parameter �ber variablenHandler initialisieren
         $_LOCALS = variablenHandler::registerLocal(array($RequestParameter => $DefaultValue));

         // Aktuellen Parameter auslesen
         $CurrentRequestParameter = $_LOCALS[$RequestParameter];

         // Content des Objekts setzen
         $this->__Content = $this->__getContent($CurrentRequestParameter);

         // Tags extrahieren
         $this->__extractTagLibTags();

         // DocumentController extrahieren
         $this->__extractDocumentController();

       // end if
      }


      /**
      *  @module __getContent()
      *  @private
      *
      *  Liest den Inhalt einer Seite aus der zugeh�rigen Datei aus. Im Fehler-<br />
      *  Fall wird eine 404-Seite angezeigt.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 30.05.2006<br />
      *  Version 0.2, 31.05.2006 (Content aus Namespace /apps/sites in Webseiten-Repository (frontend/content) verschoben)<br />
      */
      function __getContent($Seite){

         $Datei = 'frontend/content/c_'.strtolower($Seite).'.html';

         if(!file_exists($Datei)){
            $Datei = 'frontend/content/c_404.html';
          // end else
         }

         return file_get_contents($Datei);

       // end function
      }

    // end class
   }
?>