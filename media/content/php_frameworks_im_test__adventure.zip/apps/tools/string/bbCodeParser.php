<?php
   /**
   *  @package tools::string
   *  @module bbCodeParser
   *
   *  <pre>Stellt Methoden der Text-Formatierungen im bbCode-Style zur Verf�gung.
   *  Es werden folgende M�glichkeiten unterst�tzt:
   *
   *    1) Schriftformatierungen
   *       - [f](..)[/f]: Text in fett darstellen.
   *       - [k](..)[/k]: Text in kursiv darstellen.
   *       - [u](..)[/u]: Text in unterstrichen darstellen.
   *
   *    2) Schriftgr��en
   *       - [x](..)[/x]: Text in Schriftgr��e x darstellen.
   *
   *    3) Schriftfarbe
   *       - [abc](..)[/abc]: Text in Schriftfarbe abc darstellen.
   *
   *    4) Absatzformatierungen
   *       - [mitte](..)[/mitte]: Text wird mittig dargestellt.
   *       - [links](..)[/links]: Text wird linksb�ndig dargestellt (standard).
   *       - [rechts](..)[/rechts]: Text wird rechtsb�ndig dargestellt.
   *       - [block](..)[/block]: Text wird in einem Text-Block, der zentriert ist,
   *         links und rechts jeweils gleiche R�nder vom Seitenrand aufweist angezeigt.
   *       - [tab]: Text-Anfang wird mit einem Tab (Einr�ckung) versehen.
   *       - [ftrechts](..)[/ftrechts]: Eingeschlossenes Objekt (meist Bilder) werden
   *         vom Text rechts umflossen.
   *       - [ftlinks](..)[/ftlinks]: Eingeschlossenes Objekt (meist Bilder) werden
   *         vom Text links umflossen.
   *
   *    5) Grafikelemente
   *       - [Bild=abc.gif]: Hier wird das Bild abc.gif aus der Standard-Media-Library eingesetzt.
   *       - [RMBild=abc.gif,Groesse=50]: Hier wird das Bild abc.gif eingesetzt und vom Resizer auf
   *         50% der urspr�nglichen Gr��e verkleinert. Die Gr��e ist in % anzugeben. Werte > 100 sind
   *         demnach Vergr��erungen, Werte < 100 Verkleinerungen.
   *
   *    6) Verweise
   *       - [Link=(..),Hilfe=(..)](..)[/Link]: Generiert einen seiteninternen Link, der im aktuellen
   *         Fenster und innerhalb des Rahmens ausgef�hrt wird.
   *       - [Linkext=(..),Hilfe=(..)](..)[/Linkext]: Generiert einen Link mit externem Ziel, der in
   *         einem neuen Fenster ausgef�hrt wird.
   *       - [Download=(..),Hilfe=(..)](..)[/Download]: Generiert einen Download-Link, der die angegebene
   *         Datei (aus der Standard-Media-Library) zum Download anbietet. Der Link wird in einem neuen
   *         Fenster angeboten
   *
   *    7) Listen
   *       - [LP](..)[/LP]: Generiert einen Listenpunkt innerhalb einer Liste
   *       - [Liste Bild=(..)](..)[/Liste]: Generiert mit den enthaltenen Listenpunkten eine Liste mit
   *         Aufz�hlungsbild.
   *       - [Liste Typ=Strich](..)[/Liste]: Generiert mit den enthaltenen Listenpunkten eine Liste mit
   *         Aufz�hlungsstrichen.
   *       - [Liste Typ=Kreis](..)[/Liste]: Generiert mit den enthaltenen Listenpunkten eine Liste mit
   *         Aufz�hlungs-Kreisen.
   *       - [Liste Typ=Zahl](..)[/Liste]: Generiert mit den enthaltenen Listenpunkten eine Liste mit
   *         Gliederungspunkten.
   *       - [Liste](..)[/Liste]: Generiert mit den enthaltenen Listenpunkten eine einfache Liste.
   *
   *    8) Extensions
   *       Der bbCodeParser erm�glicht es Erweiterungen einzubinden. Dies sind in der Konfigurations-Datei
   *       "{APPS__ENVIRONMENT}_bbcpext.txt" im Namespace "config::modules::string::{APPS__CONTEXT}::iniconfig"
   *       in getrennten Sektionen zu definieren.
   *
   *       Beispiel:
   *          [News]
   *          Namespace = "sites::zierpflanzenberatung::biz::bbcpext"
   *          Modul = "NewsTag"
   *          Klasse = "NewsTagParser"
   *          Methode = "parseNewsTag"
   *
   *       Die Implementierungen der Extensions sollten im zugeh�rigen Sites-Namespace liegen. Im Fall von globalen
   *       Extensions k�nnen diese auch im string-Namespace unter dem Ordner "bbcpext" abgelegt werden.
   *  </pre>
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 2004<br />
   *  Version 0.2, 2004<br />
   *  Version 0.3, 10.01.2005<br />
   *  Version 0.4, 18.01.2005<br />
   *  Version 0.5, 31.01.2005<br />
   *  Version 0.6, 20.02.2005<br />
   *  Version 0.7, 14.03.2005<br />
   *  Version 0.8, 01.12.2005<br />
   *  Version 0.9, 06.02.2006<br />
   *  Version 1.0, 12.03.2006<br />
   *  Version 1.1, 01.04.2007 (iniHandler bereinigt)<br />
   */
   class bbCodeParser extends coreObject
   {

      function bbCodeParser(){
      }


      /**
      *  @module parseText()
      *  @public
      *
      *  Parst einen �bergebenen Text.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      *  Version 0.2, 10.02.2006<br />
      *  Version 0.3, 12.03.2006<br />
      */
      function parseText($Text){

         $Text = $this->__parseLetterFormat($Text);
         $Text = $this->__parseFontSizeFormat($Text);
         $Text = $this->__parseNewLine($Text);
         $Text = $this->__parseFontColorFormat($Text);
         $Text = $this->__parseArticleFormat($Text);
         $Text = $this->__parsePictureTags($Text);
         $Text = $this->__parseListTags($Text);
         $Text = $this->__parseLinkTags($Text);
         $Text = $this->__parseBlanks($Text);
         //$Text = $this->__parseSpecialCharacters($Text);
         $Text = $this->__parseExtensionTags($Text);

         return $Text;

       // end function
      }


      /**
      *  @module __parseSpecialCharacters()
      *  @private
      *
      *  Wandelt Sonderzeichen in ihre HTML-Entsprechungen um.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      */
      function __parseSpecialCharacters($Text){

         $Text = str_replace('&amp;','&',$Text);  // '&amp;' durch '&' ersetzen um Links zu erm�glichen
         $Text = htmlentities($Text);
         return $Text;

       // end function
      }


      /**
      *  @module __parseLetterFormat()
      *  @private
      *
      *  Parst Standard-Formatierungen (Fett, Kursiv, Unterstrichen).<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      */
      function __parseLetterFormat($Text){

         $Formate = array('[f]' => '<strong>',
                          '[F]' => '<strong>',
                          '[/f]' => '</strong>',
                          '[/F]' => '</strong>',
                          '[k]' => '<em>',
                          '[K]' => '<em>',
                          '[/k]' => '</em>',
                          '[/K]' => '</em>',
                          '[u]' => '<u>',
                          '[U]' => '<u>',
                          '[/u]' => '</u>',
                          '[/U]' => '</u>'
                         );
         return strtr($Text,$Formate);

       // end function
      }


      /**
      *  @module __parseFontSizeFormat()
      *  @private
      *
      *  Parst Schrift-Gr��en-Formate gem�� der Konfiguration.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      */
      function __parseFontSizeFormat($Text){

         $Config = &$this->__getConfiguration('tools::string','fonttags');
         $FontSizes = $Config->getSection('Schriftgroesse');

         foreach($FontSizes as $Key => $Value){
            $Text = strtr($Text,array('['.$Key.']' => '<font style="font-size: '.$Value.';">', '[/'.$Key.']' => '</font>'));
          // end forech
         }

         return $Text;

       // end function
      }


      /**
      *  @module __parseFontColorFormat()
      *  @private
      *
      *  Parst Schrift-Gr��en-Formate gem�� der Konfiguration.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      */
      function __parseFontColorFormat($Text){

         $Config = &$this->__getConfiguration('tools::string','fonttags');
         $Colors = $Config->getSection('Farben');

         foreach($Colors as $Key => $Value){
            $Text = strtr($Text,array('['.$Key.']' => '<font style="color: '.$Value.';">', '[/'.$Key.']' => '</font>'));
          // end forech
         }

         return $Text;

       // end function
      }


      /**
      *  @module __parseNewLine()
      *  @private
      *
      *  Parst Zeilen-Umbr�che.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      */
      function __parseNewLine($Text){
         //return str_replace("\n","<br />\n",$Text);
         return nl2br($Text);
       // end function
      }


      /**
      *  @module __parseArticleFormat()
      *  @private
      *
      *  Parst Absatz-Formate.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      */
      function __parseArticleFormat($Text){

         $Formate = array('[links]' => "<div style=\"width: 100%; text-align: left;\">",
                          '[/links]' => '</div>',
                          '[rechts]' => "<div style=\"width: 100%; text-align: right;\">",
                          '[/rechts]' => '</div>',
                          '[mitte]' => '<center>',
                          '[/mitte]' => '</center>',
                          '[block]' => "<span style=\"width: 100%; text-align: left; padding-left: 40px; padding-right: 40px;\">",
                          '[/block]' => '</span>',
                          '[tab]' => '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
                          '[ftrechts]' => "<span style=\"text-align: left; float: left; padding-top: 5px; padding-right: 10px; padding-bottom: 5px;\">",
                          '[/ftrechts]' => '</span>',
                          '[ftlinks]' => "<span style=\"text-align: right; float: right; padding-top: 5px; padding-left: 10px; padding-bottom: 5px;\">",
                          '[/ftlinks]' => '</span>'
                         );
         return strtr($Text,$Formate);

       // end function
      }


      /**
      *  @module __parseBlanks()
      *  @private
      *
      *  Parst Leerzeichen.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      */
      function __parseBlanks($Text){
         return strtr($Text,array('  ' => '&nbsp;&nbsp;'));
       // end function
      }


      /**
      *  @module __parsePictureTags()
      *  @private
      *
      *  Parst Bild-Formatierungen.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      *  Version 0.2, 17.03.2006<br />
      */
      function __parsePictureTags($Text){

         $Text = preg_replace("=\[[B|b]ild\=([^\[]*?)\]=","<img src=\"".APPS__URL_PATH."/bild.php?Bild=\\1\" align=\"absmiddle\" galleryimg=\"no\" border=\"0\" alt=\"\" />",$Text);
         $Text = preg_replace("=\[[R|r][M|m][B|b]ild\=([^\[]*?),[G|g]roesse\=([^\[]*?)\]=","<img src=\"".APPS__URL_PATH."/bild.php?Bild=\\1&Groesse=\\2\" align=\"absmiddle\" galleryimg=\"no\" border=\"0\" alt=\"\" />",$Text);
         return $Text;

       // end function
      }


      /**
      *  @module __parseLinkTags()
      *  @private
      *
      *  Parst Link-Tags.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      *  Version 0.2, 13.03.2006  (linkint-Tag entfernt, link-Tag wurde ohne callback realisiert)<br />
      *  Version 0.3, 14.03.2006  (link-Tag wird jetzt im aktuellen Browser-Fenster ausgef�hrt)<br />
      */
      function __parseLinkTags($Text){

         $Text = preg_replace("=\[[l|L]ink\=([^\[]*?),[H|h]ilfe\=([^\[]*?)\]([^\[]*?)\[\/[l|L]ink\]=","<a href=\"\\1\" title=\"\\2\">\\3</a>",$Text);
         $Text = preg_replace("=\[[l|L]inkext\=([^\[]*?),[H|h]ilfe\=([^\[]*?)\]([^\[]*?)\[\/[l|L]inkext\]=","<a href=\"\\1\" title=\"\\2\" target=\"_blank\">\\3</a>",$Text);
         $Text = preg_replace_callback("=\[[d|D]ownload\=([^\[]*?),[H|h]ilfe\=([^\[]*?)\]([^\[]*?)\[\/[d|D]ownload\]=",array('bbCodeParser','linkDLCallback'),$Text);
         return $Text;

       // end function
      }


      /**
      *  @module __parseListTags()
      *  @private
      *
      *  Parst Link-Tags.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      *  Version 0.2, 22.12.2006 (Listen-Parsing ge�ndert, dass Listen immer sauber geparst werden)<br />
      */
      function __parseListTags($Text){

         $Formate = array('[LP]' => '<li>',
                          '[/LP]' => '</li>',
                          '[lp]' => '<li>',
                          '[/lp]' => '</li>',
                          '[Lp]' => '<li>',
                          '[/Lp]' => '</li>',
                          '[lP]' => '<li>',
                          '[/lP]' => '</li>'
                         );
         $Text = strtr($Text,$Formate);

         //$Text = preg_replace("=\[[L|l]iste [B|b]ild\=([^\[]*?)\]([^\[]*?)\[\/[L|l]iste\]=","<ul style=\"list-style-image: url(".APPS__URL_PATH."/bildanzeigen.php?Bild=\\1);\">\\2</ul>",$Text);
         //$Text = preg_replace("=\[[L|l]iste [T|t]yp\=[S|s]trich\]([^\[]*?)\[\/[L|l]iste\]=","<ul style=\"list-style-type: circle;\">\\1</ul>",$Text);
         //$Text = preg_replace("=\[[L|l]iste [T|t]yp\=[K|k]reis\]([^\[]*?)\[\/[L|l]iste\]=","<ul style=\"list-style-type: disk;\">\\1</ul>",$Text);
         //$Text = preg_replace("=\[[L|l]iste [T|t]yp\=[Z|z]ahl\]([^\[]*?)\[\/[L|l]iste\]=","<ul style=\"list-style-type: decimal;\">\\1</ul>",$Text);
         //$Text = preg_replace("=\[[L|l]iste\]([^\[]*?)\[\/[L|l]iste\]=","<ul>\\1</ul>",$Text);

         // Bild-Liste parsen
         $Text = preg_replace("=\[[L|l]iste [B|b]ild\=([^\[]*?)\]=","<ul style=\"list-style-image: url(".APPS__URL_PATH."/bild.php?Bild=\\1);\">",$Text);

         // Strich-Liste parsen
         $Text = preg_replace("=\[[L|l]iste [T|t]yp\=[S|s]trich\]=","<ul style=\"list-style-type: circle;\">",$Text);

         // Kreis-Liste parsen
         $Text = preg_replace("=\[[L|l]iste [T|t]yp\=[K|k]reis\]=","<ul style=\"list-style-type: disk;\">",$Text);

         // Zahl-Liste parsen
         $Text = preg_replace("=\[[L|l]iste [T|t]yp\=[Z|z]ahl\]=","<ul style=\"list-style-type: decimal;\">",$Text);

         // Einfache Liste parsen
         $Text = preg_replace("=\[[L|l]iste\]=","<ul>",$Text);

         // Listen-Ende parsen
         $Text = preg_replace("=\[\/[L|l]iste\]=","</ul>",$Text);

         return $Text;

       // end function
      }


      /**
      *  @module __parseExtensionTags()
      *  @private
      *
      *  Bindet Extensions ein und f�hrt diese aus. Diese muss durch einen<br />
      *  Namespace, ein Modul, eine Klasse und eine Methode in der Konfiguration<br />
      *  spezifiziert werden. Die Konfiguration muss in der Datei bbcpext.txt im
      *  Namespace tools::string::{APPS__ENVIRONMENT}::iniconfig abgelegt werden.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 12.03.2006<br />
      */
      function __parseExtensionTags($Text){

         $Config = &$this->__getConfiguration('tools::string','bbcpext');
         $Extensions = $Config->getConfiguration();

         foreach($Extensions as $Extension => $Konfiguration){

            if(isset($Konfiguration['Namespace']) && isset($Konfiguration['Modul']) && isset($Konfiguration['Klasse']) && isset($Konfiguration['Methode'])){
               import($Konfiguration['Namespace'],$Konfiguration['Modul']);
               $Ext = new $Konfiguration['Klasse'];
               $Text = $Ext->{$Konfiguration['Methode']}($Text);
               unset($Ext);
             // end if
            }
            else{
               trigger_error('[bbCodeParser->__parseExtensionTags()] Configuration is not defined properly in section "'.$Extension.'"!');
             // end else
            }

          // end foreach
         }

         return $Text;

       // end function
      }


      /**
      *  @module linkDLCallback()
      *  @public
      *  @static
      *
      *  Helper-Funktion f�r __parseLinkTags() um Downloads sauber<br />
      *  darstellen zu k�nnen.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.02.2006<br />
      *  Version 0.2, 10.08.2006 (Ausgabe-Datei auf 'datei.php' angepasst)<br />
      *  Version 0.3, 17.08.2006 (Ausgabe einer Datei zum Download wurde wegen URL-Rewriting auf ein neues Fenster verlegt;!!!BETA!!!)<br />
      *  Version 0.4, 16.08.2007 (Ausgabe wieder auf normalen Link mit linkrewrite="false" zur�ckgesetzt)
      */
      function linkDLCallback($Matches){
         return '<a href="'.APPS__URL_PATH.'/datei.php?Datei='.$Matches[1].'" title="'.$Matches[2].'" target="_blank" linkrewrite="false">'.$Matches[3].'</a>';
         //return "<a href=\"#\" onClick=\"window.open('".APPS__URL_PATH."/datei.php?Datei=".$Matches[1]."','Download','toolbar=no,location=no,directories=no,status=yes,menubar=no,closed=no,scrollbars=yes,resizable=yes,copyhistory=yes,width=500,height=500')\" title=\"".$Matches[2]."\">".$Matches[3]."</a>";
       // end function
      }

    // end class
   }
?>