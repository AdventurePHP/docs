<?php
   /**
   *  @package tools::link
   *  @module linkHandler
   *  @static
   *
   *  Stellt Methoden zur Link-Pr�fung und URL-Bearbeitung bereit.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 04.05.2005<br />
   *  Version 0.2, 11.05.2005<br />
   *  Version 0.3, 27.06.2005<br />
   *  Version 0.4, 25.04.2006<br />
   *  Version 0.5, 27.03.2007 (Veraltete Methoden bereinigt)<br />
   */
   class linkHandler
   {

      function linkHandler(){
      }


      /**
      *  @module generateLink()
      *  @public
      *  @static
      *
      *  Generiert aus einer �bergebenen URI und einem Parameter-Array eine neue URI.<br />
      *  Es werden folgende Parameter �bergeben:<br />
      *  <br />
      *    - string $URL: eine g�ltige URL.<br />
      *    - array $Parameter: assoziatives, nicht mehr dimensional assoziatives, Array von URL-Parametern.<br />
      *    - boolean $RewriteLink: bei 'true' wird die URL als Pfad-URL rewritet,<br />
      *      bei 'false' so belassen.<br />
      *  <br />
      *  Die Option $Parameter bestimmt, welche Parameter der URL gel�scht, welche anders gesetzt,<br />
      *  und welche belassen werden. Aus der URL<br />
      *  <br />
      *    http://localhost/zierpflanzenberatung-neu.de/index.php?Seite=123&Button=Send&Benutzer=456&Passwort=789<br />
      *  <br />
      *  wird durch �bergabe des Arrays<br />
      *  <br />
      *    array('Seite' => 'neueSeite','Button' => '')<br />
      *  <br />
      *  die URL<br />
      *  <br />
      *    http://localhost/zierpflanzenberatung-neu.de/index.php?Seite=neueSeite&Benutzer=456&Passwort=789<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 25.04.2006<br />
      *  Version 0.2, 01.05.2006 (Bug behoben, dass Value mit L�nge 1 herausgefiltert wird)<br />
      *  Version 0.3, 06.05.2006 (Bug behoben, dass bei fehlender Query ein Fehler geworfen wird)<br />
      *  Version 0.4, 29.07.2006 (Umbau, damit Links in Rewrite-Technik sauber geparst werden)<br />
      *  Version 0.5, 14.08.2006 (Parameter "RewriteLink" wird nun standardm��ig mit der globalen Konfigurationskonstante "APPS__URL_REWRITING" gef�llt)<br />
      *  Version 0.6, 24.02.2007 (in generateLink() umbenannt)<br />
      *  Version 0.7, 27.05.2007 (Falls URL-Path nich existiert, wird dieser nun als leer angenommen)<br />
      *  Version 0.8, 02.06.2007 (Ampersands werden nun konvertiert, falls URL-Rewriting nicht aktiviert ist)<br />
      *  Version 0.9, 16.06.2007 (Ampersands werden am Anfang decodiert, da sonst Parsing-Fehler auftreten)<br />
      *  Version 1.0, 26.08.2007 (URL wird nun auf is_string() gepr�ft; URL-Parameter akzeptieren keine mehrdimensionales Arrays!)<br />
      */
      function generateLink($URL,$Parameter,$RewriteLink = APPS__URL_REWRITING){

         // Pr�fen, ob $URL ein String ist
         if(!is_string($URL)){
            trigger_error('[linkHandler::generateLink()] Given url is not a string!',E_USER_WARNING);
            $URL = strval($URL);
          // end if
         }


         // Apmersands decodieren
         $URL = str_replace('&amp;','&',$URL);


         // URL zerlegen
         $ParsedURL = parse_url($URL);


         // Query-String zerlegen
         if(!isset($ParsedURL['query'])){
            $ParsedURL['query'] = (string)'';
          // end if
         }

         // Path vorgeben, falls nicht vorhanden
         if(!isset($ParsedURL['path'])){
            $ParsedURL['path'] = (string)'';
          // end if
         }


         // URL je nach URL-Typ zerlegen
         if($RewriteLink == true){

            // Request (in diesem Fall der 'Path') in Array extrahieren
            $RequestArray = explode('/',strip_tags($ParsedURL['path']));
            array_shift($RequestArray);

            // Request-Array zur�cksetzen
            $SplitURL = array();

            // Offset-Z�hler setzen
            $x = 0;

            // RequestArray durchiterieren und auf dem Offset x den Key und auf Offset x+1
            // die Value aus der Request-URI extrahieren
            while($x <= (count($RequestArray) - 1)){

               if(isset($RequestArray[$x + 1])){
                  $SplitURL[$RequestArray[$x]] = $RequestArray[$x + 1];
                // end if
               }

               // Offset-Z�hler um 2 erh�hen
               $x = $x + 2;

             // end while
            }

            $SplitParameters = $SplitURL;

          // end if
         }
         else{
            $SplitURL = explode('&',$ParsedURL['query']);

            // Parameter der Query zerlegen
            $SplitParameters = array();

            for($i = 0; $i < count($SplitURL); $i++){

               // Nur Parameter gr��er 3 Zeichen (z.B. a=b) beachten
               if(strlen($SplitURL[$i]) > 3){

                  // Position des '=' suchen
                  $EqualSign = strpos($SplitURL[$i],'=');

                  // Array mit den Parametern als Key => Value - Paar erstellen
                  $SplitParameters[substr($SplitURL[$i],0,$EqualSign)] = substr($SplitURL[$i],$EqualSign+1,strlen($SplitURL[$i]));

                // end if
               }

             // end for
            }

          // end else
         }


         // Erzeugtes und �bergebenes Parameter-Set zusammenf�hren (dadurch k�nnen L�schungen realisiert werden)
         $SplitParameters = array_merge($SplitParameters,$Parameter);


         // Query-String an Hand der gemergten Parameter erzeugen
         $Query = (string)'';

         foreach($SplitParameters as $Key => $Value){

            // Nur Keys mit einer L�nge > 1 und Values mit einer L�nge > 0 betrachten, damit
            // ein 'Test' => '' eine L�schung bedeutet.
            // Pr�fen, ob $Value ein Array ist und dieses ablehnen!
            if(!is_array($Value)){

               if(strlen($Key) > 1 && strlen($Value) > 0){

                  // '?' als erstes Bindezeichen setzen
                  if(strlen($Query) == 0){
                     $Query .= '?';
                   // end if
                  }
                  else{
                     $Query .= '&';
                   // end else
                  }

                  // 'Key' => 'Value' - Paar zusammensetzen
                  $Query .= trim($Key).'='.trim($Value);

                // end if
               }

             // end if
            }

          // end function
         }


         // URL generieren
         $NewURL = (string)'';

         // Falls Schema und Host gegeben, diese einbinden
         if(isset($ParsedURL['scheme']) && isset($ParsedURL['host'])){
            $NewURL .= $ParsedURL['scheme'].'://'.$ParsedURL['host'];
          // end if
         }

         // Falls nur Host gegeben, diesen einsetzen
         if(!isset($ParsedURL['scheme']) && isset($ParsedURL['host'])){
            $NewURL .= '/'.$ParsedURL['host'];
          // end if
         }


         // URL final zusammensetzen
         if($RewriteLink == true){
            $FinishedURL = $NewURL.'/'.$Query;

          // end if
         }
         else{
            $FinishedURL = $NewURL.$ParsedURL['path'].$Query;
          // end else
         }


         // Link URL-Rewriten, falls gew�nscht
         if($RewriteLink == true){

            $Replace = array('./?' => '/',
                             '/?' => '/',
                             '=' => '/',
                             '&' => '/'
                            );
            $FinishedURL = strtr($FinishedURL,$Replace);

          // end if
         }
         else{

            // Ampersands codieren
            $FinishedURL = str_replace('&','&amp;',$FinishedURL);

          // end else
         }


         // Fertige URL zur�ckgeben
         return $FinishedURL;

       // end function
      }

    // end class
   }
?>