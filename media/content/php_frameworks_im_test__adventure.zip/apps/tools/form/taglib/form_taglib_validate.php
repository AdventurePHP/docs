<?php
   import('tools::form::taglib','ui_validate');


   /**
   *  @package tools::form::taglib
   *  @module form_taglib_validate
   *
   *  Repr�sentiert ein konkretes Validate-Objekt (HTML-Form).<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 25.03.2007<br />
   */
   class form_taglib_validate extends ui_element
   {

      function form_taglib_validate(){
      }

    // end class
   }
?>