<?php
   /**
   *  @package tools::form::taglib
   *  @module form_taglib_area
   *
   *  Repr�sentiert ein Text-Area-Objekt (HTML-Form).<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 13.01.2007<br />
   */
   class form_taglib_area extends ui_element
   {

      function form_taglib_area(){
      }


      /**
      *  @module transform()
      *  @public
      *
      *  Implementiert die abstrakte Methode "onAfterAppend".<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 11.02.2007<br />
      */
      function onAfterAppend(){

         // Inhalt �bertragen
         $this->__presetValue();

         // Validierung durchf�hren
         $this->__validate();

       // end function
      }


      /**
      *  @module transform()
      *
      *  Implementiert die abstrakte Methode "transform".<br />
      *
      *  @return string $TextArea; HTML-Code der Text-Area
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 05.01.2007<br />
      *  Version 0.2, 11.02.2007 (Presetting und Validierung nach onAfterAppend() verschoben)<br />
      */
      function transform(){

         // HTML-Tag zur�ckgeben
         return  '<textarea '.$this->__getAttributesAsString($this->__Attributes,$this->__ExclusionArray).'>'.$this->__Content.'</textarea>';

       // end function
      }


      /**
      *  @module __presetValue()
      *  @private
      *
      *  Implementiert die Methode "__presetValue" der Eltern-Klasse neu f�r die Text-Area.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 13.01.2007<br />
      */
      function __presetValue(){

         if(isset($_REQUEST[$this->__Attributes['name']])){
            $this->__Content = $_REQUEST[$this->__Attributes['name']];
          // end if
         }

       // end function
      }


      /**
      *  @module __validate()
      *  @private
      *
      *  Implementiert die Methode "__presetValue" der Eltern-Klasse neu f�r die Text-Area.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 13.01.2007<br />
      *  Version 0.2, 05.05.2007 ("valid or not"-Report an Form erg�nzt)<br />
      *  Version 0.3, 22.08.2007 (Fehler in Fehlermeldung korrigiert)<br />
      */
      function __validate(){

         // Pr�fen, ob eine Validierung notwendig ist
         $this->__setValidateObject();


         // Validierung durchf�hren
         if($this->__ValidateObject == true){

            // Validierung durchf�hren
            $ValidatorMethode = 'validate'.$this->__Validator;

            if(in_array(strtolower($ValidatorMethode),get_class_methods('myValidator'))){

               if(!myValidator::$ValidatorMethode($this->__Content) || !isset($_REQUEST[$this->__Attributes['name']])){

                  // Style setzen
                  if(isset($this->__Attributes['style'])){
                     $this->__Attributes['style'] .= ' '.$this->__ValidatorStyle;
                   // end if
                  }
                  else{
                     $this->__Attributes['style'] = $this->__ValidatorStyle;
                   // end else
                  }

                  // Form als nicht valide kennzeichnen
                  $this->__ParentObject->set('isValid',false);

                // end if
               }

             // end if
            }
            else{
               trigger_error('['.get_class($this).'::__validate()] Validation methode "'.$ValidatorMethode.'" is not supported in class "myValidator"! Please consult the api documentation for further details!');
             // end else
            }

          // end if
         }

       // end function
      }

    // end class
   }
?>