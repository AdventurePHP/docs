<?php
   import('tools::form::taglib','select_taglib_option');
   import('tools::form::taglib','form_taglib_select');


   /**
   *  @package tools::form::taglib
   *  @module form_taglib_multiselect
   *
   *  Repr�sentiert ein Multi-Select-Feld-Objekt (HTML-Form).<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 15.01.2007<br />
   */
   class form_taglib_multiselect extends form_taglib_select
   {

      /**
      *  @module form_taglib_select()
      *  @public
      *
      *  Konstruktor der Klasse. Initialisiert die Tag-Lib eines Select-Feldes.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 07.01.2007<br />
      *  Version 0.2, 03.03.2007 ("&" vor "new" entfernt)<br />
      *  Version 0.3, 26.08.2007 ("multiple"-Attribut wird nun automatisch gesetzt)<br />
      */
      function form_taglib_multiselect(){

         // Taglib f�r Optionen hinzuf�gen
         $this->__TagLibs[] = new TagLib('tools::form::taglib','select','option');

         // Validator-Style setzen
         $this->__ValidatorStyle = 'background-color: red;';

         // Multiselect-Attribut setzen
         $this->__Attributes['multiple'] = 'multiple';

       // end function
      }


      /**
      *  @module onParseTime()
      *  @public
      *
      *  Implementiert die Methode "onParseTime" f�r das Multi-Select-Feld neu.<br />
      *  Pr�ft, ob das
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 15.01.2007<br />
      */
      function onParseTime(){

         // Options exztrahieren
         $this->__extractTagLibTags();


         // Pr�fen, ob Name als Array initialisiert wurde
         if(!preg_match('/([A-Za-z0-9]+)\[\]$/',$this->__Attributes['name'])){

            $Form = & $this->__ParentObject;
            $Document = $Form->get('ParentObject');
            $DocumentController = $Document->get('DocumentController');
            trigger_error('[form_taglib_multiselect::onParseTime()] The attribute "name" of the &lt;form:multiselect /&gt; tag in form "'.$Form->getAttribute('name').'" in document controller "'.$DocumentController.'" must not contain whitespace characters before or between "[" or "]" !',E_USER_ERROR);
            exit();

          // end if
         }

       // end function
      }


      /**
      *  @module __presetValue()
      *  @private
      *
      *  Implementiert die Methode "__presetValue" aus der Klasse "ui_element" neu.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 15.01.2007<br />
      *  Version 0.2, 16.01.2007 (Pr�fung ob Request-Parameter gesetzt ist)<br />
      */
      function __presetValue(){

         // Offset des Request-Arrays aus Attribut generieren
         $RequestOffset = trim(str_replace('[','',str_replace(']','',$this->__Attributes['name'])));


         // Werte aus REQUEST auslesen
         if(isset($_REQUEST[$RequestOffset])){
            $Values = $_REQUEST[$RequestOffset];
          // end if
         }
         else{
            $Values = array();
          // end else
         }


         // Optionen mit entsprechenden Werten vorselektieren
         if(count($this->__Children) > 0){

            foreach($this->__Children as $ObjectID => $Child){

               if(in_array($Child->getAttribute('value'),$Values)){
                  $this->__Children[$ObjectID]->setAttribute('selected','selected');
                // end if
               }

             // end foreach
            }

          // end if
         }

       // end function
      }

    // end class
   }
?>