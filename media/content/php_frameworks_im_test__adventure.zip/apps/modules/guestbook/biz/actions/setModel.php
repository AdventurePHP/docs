<?php
   class setModel extends AbstractFrontcontrollerAction
   {

      function run(){

         echo '<br />'.get_class($this).__FUNCTION__.'()';

       // end function
      }

    // end class
   }
?>