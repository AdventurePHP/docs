<?php
   import('tools::variablen','variablenHandler');
   import('modules::kontakt4::biz','contactManager');


   /**
   *  @package modules::kontakt::pres::documentcontroller
   *  @module kontakt_v4_controller
   *
   *  Implementiert die Pr�sentationsschicht des Kontaktformulars.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 03.06.2006<br />
   *  Version 0.2, 04.06.2006<br />
   *  Version 0.3, 23.02.2007 (Implementierung nach PageController v2)<br />
   */
   class kontakt_v4_controller extends baseController
   {

      /**
      *  @private
      *  Array von lokalen Variablen.
      */
      var $_LOCALS;


      function kontakt_v4_controller(){

         $this->_LOCALS = variablenHandler::registerLocal(array('Empfaenger',
                                                                'AbsenderName',
                                                                'AbsenderAdresse',
                                                                'Betreff',
                                                                'Text'
                                                               )
                                                         );

       // end function
      }


      /**
      *  @method transformContent()
      *  @public
      *
      *  Implementiert die abstrakte Methode transformContent() des coreObjects.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 03.06.2006<br />
      *  Version 0.2, 04.06.2006<br />
      *  Version 0.3, 29.03.2007 (Form->isValid wird nun abgefragt, statt nochmal zu validieren!)<br />
      *  Version 0.4, 27.05.2007 (Status "abgesendet" wird nun per Form->isSent abgefragt!)<br />
      */
      function transformContent(){

         // Referenz auf die Form holen
         $Form = &$this->__getForm('Kontakt');

         if($Form->get('isValid') && $Form->get('isSent')){

            // Was wird gesendet?
            //
            // - Kontakt-Person-ID (Empf�nger-Person der Mail)
            // - Name
            // - E-Mail
            // - Betreff
            // - Text
            $oFD = new oFormData();
            $oFD->set('RecipientID',$this->_LOCALS['Empfaenger']);
            $oFD->set('SenderName',$this->_LOCALS['AbsenderName']);
            $oFD->set('SenderEMail',$this->_LOCALS['AbsenderAdresse']);
            $oFD->set('Subject',$this->_LOCALS['Betreff']);
            $oFD->set('Text',$this->_LOCALS['Text']);

            // Formular absenden
            $cM = &$this->__getServiceObject('modules::kontakt4::biz','contactManager');
            $cM->sendContactForm($oFD);

          // end if
         }
         else{
            $this->setPlaceHolder('Inhalt',$this->__buildForm());
          // end else
         }

       // end function
      }


      /**
      *  @method __buildForm()
      *  @private
      *
      *  Erzeugt das Kontakt-Formular.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 03.06.2006<br />
      *  Version 0.2, 04.06.2006<br />
      *  Version 0.3, 23.02.2007 (Implementierung nach PageController v2)<br />
      *  Version 0.4, 28.03.2007 (Generisches Bild in der Validatorgruppe hinzugef�gt)<br />
      */
      function __buildForm(){

         // Referenz auf die Form holen
         $Form = &$this->__getForm('Kontakt');


         // Action setzen
         $Form->setAttribute('action',$_SERVER['REQUEST_URI']);


         // Bild in der ValidatorGroup setzen (Auslesen der FormConfig)
         $Config = &$this->__getConfiguration('tools::form::taglib','formconfig');
         $ValGroup = &$Form->getFormElementByName('FormValGroup');
         $ValGroup->setPlaceHolder('WarnBild',$Config->getValue($this->__Language,'Contact.Warning.Image'));


         // Auswahlfeld Person
         $Recipients = & $Form->getFormElementByName('Empfaenger');


         // RecipientList laden
         $cM = &$this->__getServiceObject('modules::kontakt4::biz','contactManager');
         $RecipientList = $cM->loadRecipients();


         for($i = 0; $i < count($RecipientList); $i++){
            $Recipients->addOption($RecipientList[$i]->get('Name'),$RecipientList[$i]->get('oID'));
          // end if
         }


         // Formular transformieren und zur�ckgeben
         return $Form->transformForm();

       // end function
      }

    // end class
   }
?>