<?php
   /**
   *  Package modules::pager::biz<br />
   *  Klasse pageObject<br />
   *  Repr�sentiert das Business-Objekt 'pageObject'.<br />
   *  <br />
   *  Christian Sch�fer<br />
   *  Version 0.1, 06.08.2006<br />
   */
   class pageObject
   {
      
      var $__Page;
      var $__Link;
      var $__isSelected;
      var $__entriesCount;
      var $__pageCount;


      function pageObject(){
         
         $this->__Page = (string)'';
         $this->__Link = (string)'';
         $this->__isSelected = false;
         $this->__entriesCount = (int)0;
         $this->__pageCount = (int)0;
         
       // end function
      }
      

      function set($Name,$Value){

         $Attributes = array_keys(get_class_vars(get_class($this)));

         if(in_array('__'.$Name,$Attributes)){
            $this->{'__'.$Name} = $Value;
          // end if
         }
         else{
            trigger_error('['.get_class($this).'->set()] Requested attribute ('.$Name.') does not exist!');
          // end else
         }

       // end function
      }


      function get($Name){

         $Attributes = array_keys(get_class_vars(get_class($this)));

         if(in_array('__'.$Name,$Attributes)){
            return $this->{'__'.$Name};
          // end if
         }
         else{
            trigger_error('['.get_class($this).'->get()] Requested attribute ('.$Name.') does not exist!');
          // end else
         }

       // end function
      }

    // end class
   }
?>
