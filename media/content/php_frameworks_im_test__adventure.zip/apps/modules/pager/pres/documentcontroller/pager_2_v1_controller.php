<?php
   import('tools::link','linkHandler');
   import('tools::variablen','variablenHandler');


   /**
   *  @package modules::schwarzesbrett::pres::documentcontroller::pager
   *  @module pager_2_v1_controller
   *
   *  Implementiert den DocumentController f�r den PagerManager. Folgende Features sind enthalten<br />
   *  <br />
   *    - Anzeige der Seiten<br />
   *    - Vor- & Zur�ck-Button<br />
   *    - Dynamisches W�hlen der Anzahl der Eintr�ge pro Seite<br />
   *  <br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 06.08.2006<br />
   *  Version 0.2, 26.11.2006 (Pager gibt einen Leer-String zur�ck, falls keine Seiten vorhanden)<br />
   *  Version 0.3, 03.01.2007 (PageController V2 ready)<br />
   *  Version 0.4, 11.03.2007 (Komplett auf PageController V2 migriert)<br />
   */
   class pager_2_v1_controller extends baseController
   {

      var $_LOCALS;


      function pager_2_v1_controller(){
      }


      /**
      *  @module transformContent
      *  @public
      *
      *  Implementiert die abstrakte Methode 'transformContent'.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 06.08.2006<br />
      *  Version 0.2, 26.11.2006 (Pager gibt einen Leer-String zur�ck, falls keine Seiten vorhanden)<br />
      *  Version 0.3, 03.01.2007 (PageController V2 ready)<br />
      *  Version 0.4, 11.03.2007 (Komplett auf PageController V2 migriert)<br />
      */
      function transformContent(){

         // LOCALS f�llen
         $this->_LOCALS = variablenHandler::registerLocal(array($this->__Attributes['Config']['ParameterCountName'] => $this->__Attributes['Config']['EntriesPerPage']));


         // Pager leer zur�ckgeben, falls keine Seiten vorhanden sind.
         if(count($this->__Attributes['Pages']) == 0){

            // Content des aktuellen Designs leeren
            $this->__Content = '';

            // Funktion verlassen
            return '';

          // end if
         }

         $T = &Singleton::getInstance('benchmarkTimer');
         $T->start('Pager');

         // Anzahl der Seiten generieren
         $PageCount = (int) 0;

         // Aktuelle Seite generieren
         $CurrentPage = (int) 0;

         // Anzahl der Eintr�ge
         $EntriesCount = (int) 0;

         // Puffer initialisieren
         $Buffer = (string)'';

         for($i = 0; $i < count($this->__Attributes['Pages']); $i++){

            if($this->__Attributes['Pages'][$i]->get('isSelected') == true){

               // Referenz auf Template holen
               $Template = &$this->__getTemplate('Page_Selected');

               // Aktuelle Page auslesen
               $CurrentPage = $this->__Attributes['Pages'][$i]->get('Page');

             // end if
            }
            else{

               // Referenz auf Template holen
               $Template = &$this->__getTemplate('Page');

             // end else
            }

            // Pager zusammenbauen
            $Template->setPlaceHolder('Link',$this->__Attributes['Pages'][$i]->get('Link'));
            $Template->setPlaceHolder('Seite',$this->__Attributes['Pages'][$i]->get('Page'));

            // Template transformieren
            $Buffer .= $Template->transformTemplate();

            // Anzahl der Seiten setzen
            $PageCount = $this->__Attributes['Pages'][$i]->get('pageCount');

            // Anzahl der Datens�tze setzen
            $EntriesCount = $this->__Attributes['Pages'][$i]->get('entriesCount');

          // end for
         }

         // Puffer in Inhalt einsetzen
         $this->setPlaceHolder('Inhalt',$Buffer);


         // VorherigeSeite
         if($CurrentPage > 1){

            // Werte berechnen
            $Page = $CurrentPage - 1;
            $EntriesPerPage = $this->_LOCALS[$this->__Attributes['Config']['ParameterCountName']];
            $Start = ($Page * $EntriesPerPage) - $EntriesPerPage;

            // Link generieren
            $Link = linkHandler::generateLink($_SERVER['REQUEST_URI'],array($this->__Attributes['Config']['ParameterStartName'] => $Start));


            // Template vorherige Seite ausgeben
            $Template__VorherigeSeite_Aktiv = & $this->__getTemplate('VorherigeSeite_Aktiv');
            $Template__VorherigeSeite_Aktiv->setPlaceHolder('Link',$Link);
            $this->setPlaceHolder('VorherigeSeite',$Template__VorherigeSeite_Aktiv->transformTemplate());

          // end if
         }
         else{

            // Template vorherige Seite (inaktiv) ausgeben
            $Template__VorherigeSeite = & $this->__getTemplate('VorherigeSeite_Inaktiv');
            $this->setPlaceHolder('VorherigeSeite',$Template__VorherigeSeite->transformTemplate());

          // end else
         }


         // NaechsteSeite
         if($CurrentPage < $PageCount){

            // Werte berechnen
            $Page = $CurrentPage + 1;
            $EntriesPerPage = $this->_LOCALS[$this->__Attributes['Config']['ParameterCountName']];
            $Start = ($Page * $EntriesPerPage) - $EntriesPerPage;

            // Link generieren
            $Link = linkHandler::generateLink($_SERVER['REQUEST_URI'],array($this->__Attributes['Config']['ParameterStartName'] => $Start));

            $Template__NaechsteSeite_Aktiv = & $this->__getTemplate('NaechsteSeite_Aktiv');
            $Template__NaechsteSeite_Aktiv->setPlaceHolder('Link',$Link);
            $this->setPlaceHolder('NaechsteSeite',$Template__NaechsteSeite_Aktiv->transformTemplate());

          // end if
         }
         else{

            $Template__NaechsteSeite_Inaktiv = & $this->__getTemplate('NaechsteSeite_Inaktiv');
            $this->setPlaceHolder('NaechsteSeite',$Template__NaechsteSeite_Inaktiv->transformTemplate());

          // end else
         }


         // Eintr�ge / Seite
         $EntriesPerPage = array(5,10,15,20);
         $Buffer = (string)'';

         foreach($EntriesPerPage as $Key => $Value){

            if($this->_LOCALS[$this->__Attributes['Config']['ParameterCountName']] == $Value){
               $Template = &$this->__getTemplate('EntriesPerPage_Aktiv');
             // end if
            }
            else{
               $Template = & $this->__getTemplate('EntriesPerPage_Inaktiv');
             // end else
            }

            // Link generieren
            $Link = linkHandler::generateLink($_SERVER['REQUEST_URI'],array($this->__Attributes['Config']['ParameterStartName'] => '0',$this->__Attributes['Config']['ParameterCountName'] => $Value));
            $Template->setPlaceHolder('Link',$Link);

            // Anzahl einsetzen
            $Template->setPlaceHolder('Count',$Value);

            // Template in Puffer einsetzen
            $Buffer .= $Template->transformTemplate();

          // end foreach
         }

         $this->setPlaceHolder('EntriesPerPage',$Buffer);


         $T->stop('Pager');

       // end function
      }

    // end class
   }
?>