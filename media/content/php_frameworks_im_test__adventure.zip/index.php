<?php
   // Pfad zum Applikations-Verzeichnis angeben
   define('APPS__PATH','./apps');
   define('APPS__NAME','demosite');

   // ApplicationManager einbinden
   require_once(APPS__PATH.'/core/applicationmanager/ApplicationManager.php');

   // Page-Controller einbinden
   //import('core::pagecontroller','pagecontroller');
   import('core::frontcontroller','Frontcontroller');


   // Frontcontroller erzeugen
   $fC = &Singleton::getInstance('Frontcontroller');

   // Context und Sprache setzen
   $fC->set('Context','sites::demosite');
   $fC->set('Language','de');

   // Frontcontroller starten
   $fC->start('sites::demosite::pres::templates','website');


/*
   // Webseite erzeugen und ausgeben
   $Page = new Page('dokusite');
   $Page->loadDesign('sites::demosite','pres/templates/website');
   echo $Page->transform();
*/

   // Benchmark-Report ausgeben, falls benchmarkreport=true in der URL enthalten ist
   if(isset($_REQUEST['benchmarkreport'])){
      if($_REQUEST['benchmarkreport'] == 'true'){
         $T = &Singleton::getInstance('benchmarkTimer');
         echo $T->createReport();
       // end if
      }
    // end if
   }
?>