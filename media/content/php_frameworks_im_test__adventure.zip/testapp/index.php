<?php
   // Pfad zum Applikations-Verzeichnis angeben
   define('APPS__PATH','../apps');
   define('APPS__NAME','testapp');

   // ApplicationManager einbinden
   require_once(APPS__PATH.'/core/applicationmanager/ApplicationManager.php');

   // Front-Controller einbinden
   import('core::frontcontroller','Frontcontroller');


   // Frontcontroller erzeugen
   $fC = &Singleton::getInstance('Frontcontroller');

   // Context und Sprache setzen
   $fC->set('Context','sites::testapp');
   $fC->set('Language','de');


   // Frontcontroller starten
   $fC->start('sites::testapp::pres::templates','website');


   // Benchmark-Report ausgeben, falls benchmarkreport=true in der URL enthalten ist
   if(isset($_REQUEST['benchmarkreport'])){
      if($_REQUEST['benchmarkreport'] == 'true'){
         $T = &Singleton::getInstance('benchmarkTimer');
         echo $T->createReport();
       // end if
      }
    // end if
   }
?>