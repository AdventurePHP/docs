<?php
   /**
   *  <!--
   *  This file is part of the adventure php framework (APF) published under
   *  http://adventure-php-framework.org.
   *
   *  The APF is free software: you can redistribute it and/or modify
   *  it under the terms of the GNU Lesser General Public License as published
   *  by the Free Software Foundation, either version 3 of the License, or
   *  (at your option) any later version.
   *
   *  The APF is distributed in the hope that it will be useful,
   *  but WITHOUT ANY WARRANTY; without even the implied warranty of
   *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   *  GNU Lesser General Public License for more details.
   *
   *  You should have received a copy of the GNU Lesser General Public License
   *  along with the APF. If not, see http://www.gnu.org/licenses/lgpl-3.0.txt.
   *  -->
   */

   /**
   *  @namespace core::session
   *  @class sessionManager
   *
   *  Stellt ein globales Session-Handling bereit.<br />
   *  <br />
   *  Verwendungsbeispiel:
   *     $oSessMgr = new sessionManager('<namespace>');
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 08.03.2006<br />
   *  Version 0.2, 12.04.2006 (M�glichkeit hinzugef�gt die Klasse singleton instanzieren zu k�nnen)<br />
   */
   class sessionManager
   {

      /**
      *  @private
      *  Namespace der aktuellen Instanz.
      */
      var $__Namespace;


      /**
      *  @public
      *
      *  Konstruktor der Klasse.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function sessionManager($Namespace = ''){

         // Namespace setzen
         if($Namespace != ''){
            $this->setNamespace($Namespace);
          // end if
         }

         // Session initialisieren, falls noch nicht vorhanden
         if(!isset($_SESSION[$Namespace])){
            $this->createSession($Namespace);
          // end if
         }

       // end function
      }


      /**
      *  @public
      *
      *  Setzt den Namespace des aktuellen Instanz des sessionManager's.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function setNamespace($Namespace){
         $this->__Namespace = trim($Namespace);
       // end function
      }


      /**
      *  @public
      *
      *  Erzeugt einen Session-Namespace.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function createSession($Namespace){
         session_register($Namespace);
       // end function
      }


      /**
      *  @public
      *
      *  L�scht die Session im angegebenen Namespace.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      *  Version 0.2, 18.07.2006 (Bug behoben, dass nach einem neuen Post die Session wieder g�ltig war (Server w3service.net)!)<br />
      */
      function destroySession($Namespace){

         // Macht Probleme:
         // session_unregister($Namespace);
         // unset($_SESSION[$Namespace]);

         // Funktioniert:
         $_SESSION[$Namespace] = array();

       // end function
      }


      /**
      *  @public
      *
      *  L�d Benutzer-Daten aus der Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      *  Version 0.2, 15.06.2006 (Sollte ein Element nicht in der Session vorhanden sein, wird nun false statt '' zur�ckgegeben)<br />
      */
      function loadSessionData($Attribute){

         if(isset($_SESSION[$this->__Namespace][$Attribute])){
            return $_SESSION[$this->__Namespace][$Attribute];
          // end if
         }
         else{
            return false;
          // end else
         }

       // end function
      }


      /**
      *  @public
      *
      *  L�d Benutzer-Daten aus der Session unter Angabe des Namespaces.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      *  Version 0.2, 15.06.2006 (Sollte ein Element nicht in der Session vorhanden sein, wird nun false statt '' zur�ckgegeben)<br />
      */
      function loadSessionDataByNamespace($Namespace,$Attribute){

         if(isset($_SESSION[$Namespace][$Attribute])){
            return $_SESSION[$Namespace][$Attribute];
          // end if
         }
         else{
            return false;
          // end else
         }

       // end function
      }


      /**
      *  @public
      *
      *  Speichert Benutzer-Daten in die Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function saveSessionData($Attribute,$Value){
         $_SESSION[$this->__Namespace][$Attribute] = $Value;
       // end function
      }


      /**
      *  @public
      *
      *  Speichert Benutzer-Daten in die Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function saveSessionDataByNamespace($Namespace,$Attribute,$Value){
         $_SESSION[$Namespace][$Attribute] = $Value;
       // end function
      }


      /**
      *  @public
      *
      *  L�scht Benutzer-Daten in die Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function deleteSessionData($Attribute){
         unset($_SESSION[$this->__Namespace][$Attribute]);
       // end function
      }


      /**
      *  @public
      *
      *  L�scht Benutzer-Daten in die Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function deleteSessionDataByNamespace($Namespace,$Attribute){
         unset($_SESSION[$Namespace][$Attribute]);
       // end function
      }


      /**
      *  @public
      *
      *  Gibt die aktuelle Session-ID zur�ck.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function getSessionID(){
         return session_id();
       // end function
      }

    // end class
   }
?>