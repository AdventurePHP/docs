<?php
   phpinfo();
?>
