<?php
   error_reporting(E_ALL);
   ini_set('display_errors','On');
   include('./apps/core/pagecontroller/pagecontroller.php');
   $page = new Page();
   $page->loadDesign('test::yiiperf::pres::templates','main');
   echo $page->transform();
?>
