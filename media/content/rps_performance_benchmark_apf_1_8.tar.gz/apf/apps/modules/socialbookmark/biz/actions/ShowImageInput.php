<?php
 class ShowImageInput extends FrontcontrollerInput { function ShowImageInput(){ } } ?>