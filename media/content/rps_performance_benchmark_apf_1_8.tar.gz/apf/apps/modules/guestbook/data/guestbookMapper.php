<?php
 import('modules::guestbook::biz','Guestbook'); import('modules::guestbook::biz','Entry'); import('modules::guestbook::biz','Comment'); import('core::database','MySQLHandler'); class guestbookMapper extends coreObject { function guestbookMapper(){ } function loadEntryByID($EntryID){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $T = &Singleton::getInstance('benchmarkTimer'); $T->start('loadEntryByID('.$EntryID.')'); $select = 'SELECT * FROM entry WHERE EntryID = \''.$EntryID.'\';'; $result = $SQL->executeTextStatement($select); $T->start('__mapEntry2DomainObject('.$EntryID.')'); $Entry = $this->__mapEntry2DomainObject($SQL->fetchData($result)); $T->stop('__mapEntry2DomainObject('.$EntryID.')'); $T->stop('loadEntryByID('.$EntryID.')'); return $Entry; } function loadCommentByID($CommentID){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $select = 'SELECT * FROM comment WHERE CommentID = \''.$CommentID.'\';'; $result = $SQL->executeTextStatement($select); return $this->__mapComment2DomainObject($SQL->fetchData($result)); } function loadGuestbookByID($GuestbookID){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $select = 'SELECT * FROM guestbook WHERE GuestbookID = \''.$GuestbookID.'\';'; $result = $SQL->executeTextStatement($select); return $this->__mapGuestbook2DomainObject($SQL->fetchData($result)); } function loadEntryWithComments($EntyID){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $Entry = $this->loadEntryByID($EntyID); $select = 'SELECT comment.CommentID AS ID FROM comment
                    INNER JOIN comp_entry_comment ON comment.CommentID = comp_entry_comment.CommentID
                    INNER JOIN entry ON comp_entry_comment.EntryID = entry.EntryID
                    WHERE entry.EntryID = \''.$Entry->get('ID').'\';'; $result = $SQL->executeTextStatement($select); while($data = $SQL->fetchData($result)){ $Comment = $this->loadCommentByID($data['ID']); $Entry->addComment($Comment); $Comment = null; } return $Entry; } function loadGuestbookWithEntries($GuestbookID){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $Guestbook = $this->loadGuestbookByID($GuestbookID); $select = 'SELECT entry.EntryID AS ID FROM entry
                    INNER JOIN comp_guestbook_entry ON entry.EntryID = comp_guestbook_entry.EntryID
                    INNER JOIN guestbook ON comp_guestbook_entry.GuestbookID = guestbook.GuestbookID
                    WHERE guestbook.GuestbookID = \''.$Guestbook->get('ID').'\';'; $result = $SQL->executeTextStatement($select); while($data = $SQL->fetchData($result)){ $Entry = $this->loadEntryWithComments($data['ID']); $Guestbook->addEntry($Entry); $Entry = null; } return $Guestbook; } function saveGuestbook($Guestbook){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $GuestbookID = $Guestbook->get('ID'); if($GuestbookID != null){ $update = 'UPDATE guestbook SET
                       Name = \''.$SQL->escapeValue($Guestbook->get('Name')).'\',
                       Description = \''.$SQL->escapeValue($Guestbook->get('Description')).'\',
                       Admin_Username = \''.$SQL->escapeValue($Guestbook->get('Admin_Username')).'\',
                       Admin_Password = \''.$SQL->escapeValue($Guestbook->get('Admin_Password')).'\'
                       WHERE GuestbookID = \''.$GuestbookID.'\';'; $SQL->executeTextStatement($update); } else{ $insert = 'INSERT INTO guestbook

                       (
                          Name,
                          Description,
                          Admin_Username,
                          Admin_Password
                       )

                       VALUES
                       (
                          \''.$SQL->escapeValue($Guestbook->get('Name')).'\',
                          \''.$SQL->escapeValue($Guestbook->get('Description')).'\',
                          \''.$SQL->escapeValue($Guestbook->get('Admin_Username')).'\',
                          \''.$SQL->escapeValue($Guestbook->get('Admin_Password')).'\'
                       );'; $SQL->executeTextStatement($insert); $GuestbookID = $SQL->getLastID(); } $Entries = $Guestbook->getEntries(); if(count($Entries) > 0){ for($i = 0; $i < count($Entries); $i++){ $EntryID = $this->saveEntry($Entries[$i]); $select = 'SELECT * FROM comp_guestbook_entry WHERE GuestbookID  = \''.$GuestbookID.'\' AND EntryID = \''.$EntryID.'\';'; $result = $SQL->executeTextStatement($select); if($SQL->getNumRows($result) > 0){ } else{ $insert = 'INSERT INTO comp_guestbook_entry (GuestbookID,EntryID) VALUES (\''.$GuestbookID.'\',\''.$EntryID.'\');'; $SQL->executeTextStatement($insert); } } } return $GuestbookID; } function saveEntry($Entry){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $EntryID = $Entry->get('ID'); if($EntryID != null){ $update = 'UPDATE entry SET
                       Name = \''.$SQL->escapeValue($Entry->get('Name')).'\',
                       EMail = \''.$SQL->escapeValue($Entry->get('EMail')).'\',
                       City = \''.$SQL->escapeValue($Entry->get('City')).'\',
                       Website = \''.$SQL->escapeValue($Entry->get('Website')).'\',
                       ICQ = \''.$SQL->escapeValue($Entry->get('ICQ')).'\',
                       MSN = \''.$SQL->escapeValue($Entry->get('MSN')).'\',
                       Skype = \''.$SQL->escapeValue($Entry->get('Skype')).'\',
                       AIM = \''.$SQL->escapeValue($Entry->get('AIM')).'\',
                       Yahoo = \''.$SQL->escapeValue($Entry->get('Yahoo')).'\',
                       Text = \''.$SQL->escapeValue($Entry->get('Text')).'\'
                       WHERE EntryID = \''.$EntryID.'\';'; $SQL->executeTextStatement($update); } else{ $insert = 'INSERT INTO entry

                       (
                          Name,
                          EMail,
                          City,
                          Website,
                          ICQ,
                          MSN,
                          Skype,
                          AIM,
                          Yahoo,
                          Text,
                          Date,
                          Time
                       )

                       VALUES
                       (
                          \''.$SQL->escapeValue($Entry->get('Name')).'\',
                          \''.$SQL->escapeValue($Entry->get('EMail')).'\',
                          \''.$SQL->escapeValue($Entry->get('City')).'\',
                          \''.$SQL->escapeValue($Entry->get('Website')).'\',
                          \''.$SQL->escapeValue($Entry->get('ICQ')).'\',
                          \''.$SQL->escapeValue($Entry->get('MSN')).'\',
                          \''.$SQL->escapeValue($Entry->get('Skype')).'\',
                          \''.$SQL->escapeValue($Entry->get('AIM')).'\',
                          \''.$SQL->escapeValue($Entry->get('Yahoo')).'\',
                          \''.$SQL->escapeValue($Entry->get('Text')).'\',
                          CURDATE(),
                          CURTIME()
                       );'; $SQL->executeTextStatement($insert); $EntryID = $SQL->getLastID(); } $Comments = $Entry->getComments(); if(count($Comments) > 0){ for($i = 0; $i < count($Comments); $i++){ $CommentID = $this->saveComment($Comments[$i]); $select = 'SELECT * FROM comp_entry_comment WHERE EntryID = \''.$EntryID.'\' AND CommentID = \''.$CommentID.'\';'; $result = $SQL->executeTextStatement($select); if($SQL->getNumRows($result) > 0){ } else{ $insert = 'INSERT INTO comp_entry_comment (EntryID,CommentID) VALUES (\''.$EntryID.'\',\''.$CommentID.'\');'; $SQL->executeTextStatement($insert); } } } return $EntryID; } function saveComment($Comment){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $CommentID = $Comment->get('ID'); if($CommentID != null){ $update = 'UPDATE comment SET
                       Title = \''.$SQL->escapeValue($Comment->get('Title')).'\',
                       Text = \''.$SQL->escapeValue($Comment->get('Text')).'\'
                       WHERE CommentID = \''.$CommentID.'\';'; $SQL->executeTextStatement($update); } else{ $insert = 'INSERT INTO comment

                       (
                          Title,
                          Text,
                          Date,
                          Time
                       )

                       VALUES
                       (
                          \''.$SQL->escapeValue($Comment->get('Title')).'\',
                          \''.$SQL->escapeValue($Comment->get('Text')).'\',
                          CURDATE(),
                          CURTIME()
                       );'; $SQL->executeTextStatement($insert); $CommentID = $SQL->getLastID(); } return $CommentID; } function deleteEntry($Entry){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $select_commment = 'SELECT comment.CommentID AS ID FROM comment
                             INNER JOIN comp_entry_comment ON comment.CommentID = comp_entry_comment.CommentID
                             INNER JOIN entry ON comp_entry_comment.EntryID = entry.EntryID
                             WHERE entry.EntryID = \''.$Entry->get('ID').'\';'; $result_comment = $SQL->executeTextStatement($select_commment); while($data_comment = $SQL->fetchData($result_comment)){ $delete_comment = 'DELETE FROM comment WHERE CommentID = \''.$data_comment['ID'].'\';'; $SQL->executeTextStatement($delete_comment); $delete_comp_comment = 'DELETE FROM comp_entry_comment WHERE CommentID = \''.$data_comment['ID'].'\';'; $SQL->executeTextStatement($delete_comp_comment); $delete_comment = null; $delete_comp_comment = null; } $delete_entry = 'DELETE FROM entry WHERE EntryID = \''.$Entry->get('ID').'\';'; $SQL->executeTextStatement($delete_entry); $delete_comp_entry = 'DELETE FROM comp_guestbook_entry WHERE EntryID = \''.$Entry->get('ID').'\';'; $SQL->executeTextStatement($delete_comp_entry); } function deleteComment($Comment){ $SQL = &$this->__getServiceObject('core::database','MySQLHandler'); $delete_comp_comment = 'DELETE FROM comp_entry_comment WHERE CommentID = \''.$Comment->get('ID').'\';'; $SQL->executeTextStatement($delete_comp_comment); $delete_comment = 'DELETE FROM comment WHERE CommentID = \''.$Comment->get('ID').'\';'; $SQL->executeTextStatement($delete_comment); } function __mapEntry2DomainObject($EntryResultSet){ $Entry = new Entry(); if(isset($EntryResultSet['EntryID'])){ $Entry->set('ID',$EntryResultSet['EntryID']); } if(isset($EntryResultSet['Name'])){ $Entry->set('Name',$EntryResultSet['Name']); } if(isset($EntryResultSet['EMail'])){ $Entry->set('EMail',$EntryResultSet['EMail']); } if(isset($EntryResultSet['City'])){ $Entry->set('City',$EntryResultSet['City']); } if(isset($EntryResultSet['Website'])){ $Entry->set('Website',$EntryResultSet['Website']); } if(isset($EntryResultSet['ICQ'])){ $Entry->set('ICQ',$EntryResultSet['ICQ']); } if(isset($EntryResultSet['MSN'])){ $Entry->set('MSN',$EntryResultSet['MSN']); } if(isset($EntryResultSet['Skype'])){ $Entry->set('Skype',$EntryResultSet['Skype']); } if(isset($EntryResultSet['AIM'])){ $Entry->set('AIM',$EntryResultSet['AIM']); } if(isset($EntryResultSet['Yahoo'])){ $Entry->set('Yahoo',$EntryResultSet['Yahoo']); } if(isset($EntryResultSet['Text'])){ $Entry->set('Text',$EntryResultSet['Text']); } if(isset($EntryResultSet['Date'])){ $Entry->set('Date',$EntryResultSet['Date']); } if(isset($EntryResultSet['Time'])){ $Entry->set('Time',$EntryResultSet['Time']); } return $Entry; } function __mapGuestbook2DomainObject($GuestbookResultSet){ $Guestbook = new Guestbook(); if(isset($GuestbookResultSet['GuestbookID'])){ $Guestbook->set('ID',$GuestbookResultSet['GuestbookID']); } if(isset($GuestbookResultSet['Name'])){ $Guestbook->set('Name',$GuestbookResultSet['Name']); } if(isset($GuestbookResultSet['Description'])){ $Guestbook->set('Description',$GuestbookResultSet['Description']); } if(isset($GuestbookResultSet['Admin_Username'])){ $Guestbook->set('Admin_Username',$GuestbookResultSet['Admin_Username']); } if(isset($GuestbookResultSet['Admin_Password'])){ $Guestbook->set('Admin_Password',$GuestbookResultSet['Admin_Password']); } return $Guestbook; } function __mapComment2DomainObject($CommentResultSet){ $Comment = new Comment(); if(isset($CommentResultSet['CommentID'])){ $Comment->set('ID',$CommentResultSet['CommentID']); } if(isset($CommentResultSet['Title'])){ $Comment->set('Title',$CommentResultSet['Title']); } if(isset($CommentResultSet['Text'])){ $Comment->set('Text',$CommentResultSet['Text']); } if(isset($CommentResultSet['Date'])){ $Comment->set('Date',$CommentResultSet['Date']); } if(isset($CommentResultSet['Time'])){ $Comment->set('Time',$CommentResultSet['Time']); } return $Comment; } } ?>