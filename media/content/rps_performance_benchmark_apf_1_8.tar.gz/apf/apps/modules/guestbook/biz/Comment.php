<?php
 class Comment extends coreObject { var $__ID = null; var $__Title; var $__Date; var $__Text; var $__Time; function Comment(){ } } ?>