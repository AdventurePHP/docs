<?php
 class oFormData extends coreObject { var $__RecipientID; var $__SenderName; var $__SenderEMail; var $__Subject; var $__Text; function oFormData(){ $this->__RecipientID = (string)''; $this->__SenderName = (string)''; $this->__SenderEMail = (string)''; $this->__Subject = (string)''; $this->__Text = (string)''; } } ?>
