<?php
 class oRecipient extends coreObject { var $__Name; var $__Adresse; function oRecipient(){ $this->__Name = (string)''; $this->__Adresse = (string)''; } } ?>
