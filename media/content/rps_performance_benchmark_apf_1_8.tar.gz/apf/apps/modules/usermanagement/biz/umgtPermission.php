<?php
 import('modules::usermanagement::biz','umgtBase'); class umgtPermission extends umgtBase { var $__Key; var $__Value; function umgtPermission(){ } } ?>