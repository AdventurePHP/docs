<?php
 import('modules::genericormapper::biz','GenericDomainObject'); class umgtUser extends GenericDomainObject { function umgtUser(){ $this->__ObjectName = 'User'; } } ?>