<?php
 import('modules::usermanagement::biz','umgtBase'); class umgtGroup extends umgtBase { var $__Users = array(); function umgtGroup(){ } } ?>