<?php
 class ShowCaptchaImageInput extends FrontcontrollerInput { function ShowCaptchaImageInput(){ } } ?>