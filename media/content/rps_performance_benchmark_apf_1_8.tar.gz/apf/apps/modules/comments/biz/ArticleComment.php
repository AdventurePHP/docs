<?php
 class ArticleComment extends coreObject { var $__ID = null; var $__Name; var $__EMail; var $__Comment; var $__Date; var $__Time; var $__CategoryKey; function ArticleComment(){ } } ?>