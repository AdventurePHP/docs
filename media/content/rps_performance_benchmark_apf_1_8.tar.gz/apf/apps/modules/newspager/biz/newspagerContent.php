<?php
 class newspagerContent extends coreObject { var $__Headline; var $__Subheadline; var $__Content; var $__NewsCount; function newspagerContent(){ } } ?>