<?php
 class newspagerInput extends FrontcontrollerInput { function newspagerInput(){ } } ?>