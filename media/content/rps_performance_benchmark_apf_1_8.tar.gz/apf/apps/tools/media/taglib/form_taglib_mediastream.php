<?php
 import('tools::media::taglib','ui_mediastream'); class form_taglib_mediastream extends ui_mediastream { function form_taglib_mediastream(){ } } ?>