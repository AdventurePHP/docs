<?php
 import('tools::media::taglib','ui_mediastream'); class html_taglib_mediastream extends ui_mediastream { function html_taglib_mediastream(){ } } ?>