<?php
 import('tools::media::taglib','ui_mediastream'); class template_taglib_mediastream extends ui_mediastream { function template_taglib_mediastream(){ } } ?>