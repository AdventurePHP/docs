<?php
 class StreamMediaInput extends FrontcontrollerInput { function StreamMediaInput(){ } } ?>