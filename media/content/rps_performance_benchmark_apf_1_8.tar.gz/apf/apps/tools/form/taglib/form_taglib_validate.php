<?php
 import('tools::form::taglib','ui_validate'); class form_taglib_validate extends ui_element { function form_taglib_validate(){ } } ?>