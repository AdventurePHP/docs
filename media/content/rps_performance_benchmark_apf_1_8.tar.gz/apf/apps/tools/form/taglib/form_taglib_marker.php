<?php
 class form_taglib_marker extends Document { function form_taglib_marker(){ } function onParseTime(){ } function onAfterAppend(){ } function transform(){ return (string)''; } } ?>