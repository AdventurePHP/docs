<?php
 import('tools::html::taglib','ui_getstring'); class form_taglib_getstring extends ui_getstring { function form_taglib_getstring(){ } } ?>