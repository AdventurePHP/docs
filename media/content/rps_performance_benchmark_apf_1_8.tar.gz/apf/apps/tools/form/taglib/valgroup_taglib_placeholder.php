<?php
 class valgroup_taglib_placeholder extends ui_element { function valgroup_taglib_placeholder(){ } } ?>