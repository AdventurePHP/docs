<?php
 class form_taglib_placeholder extends ui_element { function form_taglib_placeholder(){ } } ?>