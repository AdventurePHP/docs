<?php
 import('tools::form::taglib','ui_validate'); class valgroup_taglib_validate extends ui_validate { function valgroup_taglib_validate(){ } } ?>