<?php
 class form_taglib_addtaglib extends core_taglib_addtaglib { function form_taglib_addtaglib(){ } } ?>