<?php
 class NewLineProvider extends BBCodeParserProvider { function NewLineProvider(){ } function getOutput($string){ return nl2br($string); } } ?>