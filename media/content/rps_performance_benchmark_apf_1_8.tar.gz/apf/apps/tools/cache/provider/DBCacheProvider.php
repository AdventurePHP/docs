<?php
 import('core::database','connectionManager'); class DBCacheProvider extends AbstractCacheProvider { function DBCacheProvider(){ } function read($cacheKey){ $namespace = $this->__getCacheConfigAttribute('Cache.Namespace'); $tableName = $this->__getCacheConfigAttribute('Cache.Table'); $db = &$this->__getDatabaseConnection(); $select = 'SELECT `value` FROM `'.$tableName.'`
                    WHERE
                       `namespace` = \''.$namespace.'\'
                       AND
                       `cachekey` = \''.$cacheKey.'\';'; $result = $db->executeTextStatement($select); $data = $db->fetchData($result); if(isset($data['value'])){ return $data['value']; } else{ return null; } } function write($cacheKey,$object){ $namespace = $this->__getCacheConfigAttribute('Cache.Namespace'); $tableName = $this->__getCacheConfigAttribute('Cache.Table'); $db = &$this->__getDatabaseConnection(); $select = 'SELECT `value` FROM `'.$tableName.'`
                    WHERE
                       `namespace` = \''.$namespace.'\'
                       AND
                       `cachekey` = \''.$cacheKey.'\';'; $result = $db->executeTextStatement($select); $count = $db->getNumRows($result); if($count > 0){ $stmt = 'UPDATE `'.$tableName.'`
                     SET `value` = \''.$object.'\'
                     WHERE
                        `namespace` = \''.$namespace.'\'
                        AND
                        `cachekey` = \''.$cacheKey.'\';'; } else{ $stmt = 'INSERT INTO `'.$tableName.'`
                     (`value`,`namespace`,`cachekey`)
                     VALUES
                     (\''.$object.'\',\''.$namespace.'\',\''.$cacheKey.'\');'; } $db->executeTextStatement($stmt); return true; } function clear($cacheKey = null){ $namespace = $this->__getCacheConfigAttribute('Cache.Namespace'); $tableName = $this->__getCacheConfigAttribute('Cache.Table'); $db = &$this->__getDatabaseConnection(); if($cacheKey === null){ $delete = 'DELETE FROM `'.$tableName.'`
                       WHERE `namespace` = \''.$namespace.'\';'; } else{ $delete = 'DELETE FROM `'.$tableName.'`
                       WHERE
                          `namespace` = \''.$namespace.'\'
                          AND
                          `cachekey` = \''.$cacheKey.'\';'; } $db->executeTextStatement($delete); return true; } function &__getDatabaseConnection(){ $connectionKey = $this->__getCacheConfigAttribute('Cache.Connection'); $cM = &$this->__getServiceObject('core::database','connectionManager'); return $cM->getConnection($connectionKey); } } ?>