<?php
 import('tools::html::taglib','ui_getstring'); class html_taglib_getstring extends ui_getstring { function html_taglib_getstring(){ } } ?>