<?php
 class item_taglib_placeholder extends html_taglib_placeholder { function item_taglib_placeholder(){ } } ?>