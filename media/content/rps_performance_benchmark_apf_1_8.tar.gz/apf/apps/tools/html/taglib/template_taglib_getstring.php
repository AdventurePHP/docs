<?php
 import('tools::html::taglib','ui_getstring'); class template_taglib_getstring extends ui_getstring { function template_taglib_getstring(){ } } ?>