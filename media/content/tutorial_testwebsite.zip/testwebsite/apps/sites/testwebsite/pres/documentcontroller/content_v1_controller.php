<?php
   // include MySQLHandler
   import('core::database','MySQLHandler');

   // document controller class to display dynamic content
   class content_v1_controller extends baseController
   {

      function content_v1_controller(){
      }

      function transformContent(){

         // get an instance of the MySQLHandler
         $SQL = $this->__getServiceObject('core::database','MySQLHandler');


         // retrieve URL parameters
         if(isset($_REQUEST['Page']) && !empty($_REQUEST['Page'])){
            $Page = $_REQUEST['Page'];
          // end if
         }
         else{
            $Page = 'Startseite';
          // end else
         }


         // read page content from database
         $select = 'SELECT PageContent
                    FROM demopage_content
                    WHERE PageURLName = \''.$Page.'\'
                    LIMIT 1';
         $result = $SQL->executeTextStatement($select);
         $data = $SQL->fetchData($result);


         // display content by adding the content to the
         // $__Content member of the current document
         $this->__Content = $data['PageContent'];

       // end function
      }

    // end class
   }
?>