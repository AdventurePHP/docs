<?php
import('tools::request', 'RequestHandler');

class content_v1_controller extends base_controller {

   public function transformContent() {

      $cM = &$this->getServiceObject('core::database', 'ConnectionManager');
      /* @var $cM ConnectionManager*/
      $SQL = &$cM->getConnection('content-database');
      /* @var $SQL AbstractDatabaseHandler */

      // URL-Parameter beziehen
      $page = RequestHandler::getValue('Seite', 'Startseite');

      // Parameter gegen SQL-Injections absichern
      $page = $SQL->escapeValue($page);

      // Inhalt der Seite auslesen
      $select = 'SELECT PageContent
                 FROM demopage_content
                 WHERE PageURLName = \'' . $page . '\'
                 LIMIT 1';
      $result = $SQL->executeTextStatement($select);
      $data = $SQL->fetchData($result);

      // Inhalt der Seite ausgeben
      $this->setContent($data['PageContent']);
   }
}

?>