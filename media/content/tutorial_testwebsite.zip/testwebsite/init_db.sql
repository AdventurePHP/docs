CREATE TABLE IF NOT EXISTS `demopage_content` (
  `PageID` tinyint(5) NOT NULL auto_increment,
  `PageURLName` varchar(50) collate latin1_german1_ci NOT NULL default '',
  `PageTitle` varchar(50) collate latin1_german1_ci NOT NULL default '',
  `PageContent` text collate latin1_german1_ci NOT NULL,
  PRIMARY KEY  (`PageID`),
  UNIQUE KEY `PageURLName` (`PageURLName`),
  KEY `PageTitle` (`PageTitle`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci COMMENT='Inhalt einer Webseite' AUTO_INCREMENT=3 ;

INSERT INTO `demopage_content` (`PageID`, `PageURLName`, `PageTitle`, `PageContent`) VALUES
(1, 'Startseite', 'Startseite', 'Herzlich Willkommen auf der TestWebsite!'),
(2, 'Impressum', 'Impressum', 'Verantwortlich f�r Inhalt und Design:\r\n\r\nHans Mustermann\r\nMusterstra�e 123\r\n12345 Musterhausen');
