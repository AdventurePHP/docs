CREATE TABLE IF NOT EXISTS `demopage_content` (
  `PageID` tinyint(5) NOT NULL auto_increment,
  `PageURLName` varchar(50) collate uft8_general_ci NOT NULL default '',
  `PageTitle` varchar(50) collate uft8_general_ci NOT NULL default '',
  `PageContent` text collate uft8_general_ci NOT NULL,
  PRIMARY KEY  (`PageID`),
  UNIQUE KEY `PageURLName` (`PageURLName`),
  KEY `PageTitle` (`PageTitle`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=uft8_general_ci COMMENT='Inhalt einer Webseite';

INSERT INTO `demopage_content` (`PageID`, `PageURLName`, `PageTitle`, `PageContent`) VALUES
(1, 'Startseite', 'Startseite', 'Herzlich Willkommen auf der TestWebsite!'),
(2, 'Impressum', 'Impressum', 'Verantwortlich für Inhalt und Design:\r\n\r\nHans Mustermann\r\nMusterstraße 123\r\n12345 Musterhausen');
