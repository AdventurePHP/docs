<?php
   // include page controller
   require_once('./apps/core/pagecontroller/pagecontroller.php');

   // create a new page
   $Page = new Page();

   // load the main template
   $Page->loadDesign('sites::testwebsite','pres/templates/website');

   // transform and display page
   echo $Page->transform();

   // generate benchmark report
   $T = &Singleton::getInstance('BenchmarkTimer');
   echo $T->createReport();
?>