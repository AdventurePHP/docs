<?php
// include page controller
include_once('./apps/core/pagecontroller/pagecontroller.php');
import('core::frontcontroller', 'Frontcontroller');

$fC = &Singleton::getInstance('Frontcontroller');
/* @var $fC Frontcontroller */
$fC->setContext('projectone');
echo $fC->start('sites::testwebsite::pres::templates', 'website');
?>