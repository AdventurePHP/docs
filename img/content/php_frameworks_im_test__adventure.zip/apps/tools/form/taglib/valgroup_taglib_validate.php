<?php
   import('tools::form::taglib','ui_validate');


   /**
   *  @package tools::form::taglib
   *  @module valgroup_taglib_validate
   *
   *  Repr�sentiert ein konkretes Validate-Objekt (HTML-Form).<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 25.03.2007<br />
   */
   class valgroup_taglib_validate extends ui_validate
   {

      function valgroup_taglib_validate(){
      }

    // end class
   }
?>