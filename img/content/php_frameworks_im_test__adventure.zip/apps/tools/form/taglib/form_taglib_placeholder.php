<?php
   /**
   *  @package tools::form::taglib
   *  @module form_taglib_placeholder
   *
   *  Repr�sentiert ein Platzhalter-Objekt in einer HTML-Form.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 05.01.2007<br />
   *  Version 0.2, 12.01.2006 (Umbenannt in "form_taglib_placeholder")<br />
   */
   class form_taglib_placeholder extends ui_element
   {

      function form_taglib_placeholder(){
      }

    // end class
   }
?>