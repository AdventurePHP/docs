<?php
   /**
   *  @package tools::form::taglib
   *  @module valgroup_taglib_placeholder
   *
   *  Repr�sentiert ein Platzhalter-Objekt in einer Validator-Gruppe.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 28.03.2007 (Platzhalter f�r Validator-Gruppen eingef�hrt)<br />
   */
   class valgroup_taglib_placeholder extends ui_element
   {

      function valgroup_taglib_placeholder(){
      }

    // end class
   }
?>