<?php
   import('tools::form::taglib','select_taglib_option');


   /**
   *  @package tools::form::taglib
   *  @module form_taglib_select
   *
   *  Repr�sentiert ein Select-Feld-Objekt (HTML-Form).<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 07.01.2007<br />
   *  Version 0.2, 12.01.2007 (Umbenannt in "form_taglib_select")<br />
   */
   class form_taglib_select extends ui_element
   {

      /**
      *  @module form_taglib_select()
      *  @public
      *
      *  Konstruktor der Klasse. Initialisiert die Tag-Lib eines Select-Feldes.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 07.01.2007<br />
      *  Version 0.2, 03.03.2007 ("&" vor "new" entfernt)<br />
      */
      function form_taglib_select(){

         // Taglib f�r Optionen hinzuf�gen
         $this->__TagLibs[] = new TagLib('tools::form::taglib','select','option');

         // Validator-Style setzen
         $this->__ValidatorStyle = 'background-color: red;';

       // end function
      }


      /**
      *  @module onParseTime()
      *  @public
      *
      *  Extrahiert die Option-Tags.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 07.01.2007<br />
      */
      function onParseTime(){
         $this->__extractTagLibTags();
       // end function
      }


      /**
      *  @module transform()
      *  @public
      *
      *  Implementiert die abstrakte Methode "onAfterAppend".<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 11.02.2007<br />
      */
      function onAfterAppend(){

         // Inhalt �bertragen
         $this->__presetValue();

         // Validierung durchf�hren
         $this->__validate();

       // end function
      }


      /**
      *  @module setOption2Selected()
      *  @public
      *
      *  Setzte den Status einer mit $Name deklarierten Option auf 'selected'.<br />
      *
      *  @param string $DisplayName; Setzt den Status einer Option, die mit $DisplayName spezifiziert ist auf "selected".
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 07.01.2007<br />
      */
      function setOption2Selected($DisplayName){

         // Option-Counter initialisieren
         $OptionCount = 0;

         if(count($this->__Children) > 0){

            foreach($this->__Children as $ObjectID => $Child){

               if(trim($Child->get('Content')) == $DisplayName){
                  $this->__Children[$ObjectID]->setAttribute('selected','selected');
                  $OptionCount++;
                // end if
               }

             // end foreach
            }

          // end if
         }

         // Warnung ausgeben, falls kein Element gefunden wurde
         if($OptionCount < 1){
            trigger_error('[form_taglib_selectfield::setOption2Selected()] No option wir name "'.$DisplayName.'" found in form "'.$this->__Attributes['name'].'"!');
          // end if
         }

       // end function
      }


      /**
      *  @module addOption()
      *  @public
      *
      *  F�gt zum Select-Feld eine Option hinzu.<br />
      *
      *  @param string $DisplayName; Dieplay-Name der Option
      *  @param string $Value; Wert der Option
      *  @param bool $PreSelected; true | false (optional)
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 07.01.2007<br />
      */
      function addOption($DisplayName,$Value,$PreSelected = false){

         // Objekt-ID generieren
         $ObjectID = xmlParser::generateUniqID();


         // Neues Options-Objekt erzeugen
         $this->__Children[$ObjectID] = new select_taglib_option();


         // Attribute setzen
         $this->__Children[$ObjectID]->set('Content',$DisplayName);
         $this->__Children[$ObjectID]->setAttribute('value',$Value);

         if($PreSelected == true){
            $this->__Children[$ObjectID]->setAttribute('selected','selected');
          // end if
         }


         // Vater bekannt machen
         $this->__Children[$ObjectID]->setByReference('ParentObject',$this);


         // XML-Merker-Tag in den Content einpflegen
         $this->__Content .= '<'.$ObjectID.' />';

       // end function
      }


      /**
      *  @module transform()
      *  @public
      *
      *  Transformiert ein Select-Feld-Objekt.<br />
      *
      *  @return string $SelectField; HTML-Code des Select-Felds
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 07.01.2007<br />
      *  Version 0.2, 12.01.2007 (Sch�nheitskorrekturen)<br />
      *  Version 0.3, 11.02.2007 (Presetting und Validierung nach onAfterAppend() verschoben)<br />
      */
      function transform(){

         // Validierung nachbehandeln
         unset($this->__Attributes['value']);


         // Form transformieren
         $HTML_Select = (string)'';
         $HTML_Select .= '<select '.$this->__getAttributesAsString($this->__Attributes,$this->__ExclusionArray).'>';

         $Content = $this->__Content;

         if(count($this->__Children) > 0){

            foreach($this->__Children as $ObjectID => $Child){

               if(isset($_REQUEST[$this->getAttribute('name')]) && !empty($_REQUEST[$this->getAttribute('name')])){

                  if($Child->getAttribute('value') == $_REQUEST[$this->getAttribute('name')]){
                     $this->__Children[$ObjectID]->setAttribute('selected','selected');
                   // end if
                  }
                  else{
                     $this->__Children[$ObjectID]->deleteAttribute('selected');
                   // end else
                  }

                // end if
               }

               $Content = str_replace('<'.$ObjectID.' />',$this->__Children[$ObjectID]->transform(),$Content);

             // end foreach
            }

          // end if
         }

         $HTML_Select .= $Content;
         $HTML_Select .= '</select>';


         // Form zur�ckgeben
         return $HTML_Select;

       // end function
      }

    // end class
   }
?>