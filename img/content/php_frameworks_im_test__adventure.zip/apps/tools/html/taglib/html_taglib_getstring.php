<?php
   import('tools::html::taglib','ui_getstring');


   /**
   *  @package tools::html::taglib
   *  @module html_taglib_getstring
   *
   *  Implementiert die TagLib f�r den Tag "<html:getstring />".<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 21.04.2006<br />
   */
   class html_taglib_getstring extends ui_getstring
   {

      function html_taglib_getstring(){
      }

    // end class
   }
?>