<?php
   import('tools::variablen','variablenHandler');
   import('modules::filebasedsearch::biz','fileBasedSearchManager');


   /**
   *  @package modules::filebasedsearch::pres
   *  @module filebasedsearch_v1_controller
   *
   *  Implementiert den DocumentController f�r das Template 'filebasedsearch.html'.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 16.06.2007<br />
   */
   class filebasedsearch_v1_controller extends baseController
   {

      /**
      *  @private
      *  Speichert lokal verwendete Variablen.
      */
      var $_LOCALS;


      function filebasedsearch_v1_controller(){
         $this->_LOCALS = variablenHandler::registerLocal(array('SearchString' => '','Seite' => 'Startseite'));
       // end function
      }


      /**
      *  @module transformContent()
      *  @public
      *
      *  Implementiert die abstrakte Methode transformContent() aus coreObject.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 16.06.2007<br />
      */
      function transformContent(){

         // Form holen
         $Form__SearchForm = &$this->__getForm('SearchForm');


         // Pr�fen, ob Formular abgeschickt und korrekt ausgef�llt
         if($Form__SearchForm->get('isValid') && $Form__SearchForm->get('isSent')){

            // Manager holen
            $fSM = &$this->__getServiceObject('modules::filebasedsearch::biz','fileBasedSearchManager');


            // Ergebnisse laden
            $SearchResult = $fSM->getSearchResult($this->_LOCALS['SearchString']);


            // Ausgabe-Puffer initialisieren
            $Buffer = (string)'';


            // Header einsetzen
            $Template__SearchResultHeader = &$this->__getTemplate('SearchResultHeader');
            $Buffer .= $Template__SearchResultHeader->transformTemplate();

            foreach($SearchResult as $Number => $ResultObject){
               $Buffer .= $this->__buildSearchResult($ResultObject);
             // end foreach
            }


            // Ausgabe f�r keine Ergebnisse
            if(count($SearchResult) < 1){

               // Template holen
               $Template__NoSearchResult = &$this->__getTemplate('NoSearchResult');

               // Meldung in Platzhalter einsetzen
               $Buffer .= $Template__NoSearchResult->transformTemplate();

             // end if
            }


            // Liste in Platzhalter einsetzen
            $this->setPlaceHolder('SearchResult',$Buffer);

          // end if
         }


         // Formular ausgeben
         $this->setPlaceHolder('SearchForm',$Form__SearchForm->transformForm());

       // end function
      }


      /**
      *  @module __buildSearchResult()
      *  @private
      *
      *  Erzeugt die HTML-Ausgabe f�r ein Ergebnis.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 16.06.2007<br />
      *  Version 0.2, 24.06.2007 (Titel wird nun im Ergebnis-Objekt schon mitgeliefert)<br />
      */
      function __buildSearchResult($SearchResult){

         // Template holen
         $Template__SearchResult = &$this->__getTemplate('SearchResult');

         // Werte einsetzen
         $Title = ucfirst($SearchResult->get('Title'));
         $Template__SearchResult->setPlaceHolder('Title',$Title);
         $Template__SearchResult->setPlaceHolder('Link',APPS__URL_PATH.'/Seite/'.$Title);
         $Template__SearchResult->setPlaceHolder('Content',$SearchResult->get('Content'));
         $Template__SearchResult->setPlaceHolder('Size',$SearchResult->get('Size'));

         // Ergebnis zur�ckgeben
         return $Template__SearchResult->transformTemplate();

       // end function
      }

    // end class
   }
?>