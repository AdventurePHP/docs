<?php
   import('modules::kontakt4::biz','abstractObject');


   /**
   *  Package modules::kontakt2::biz<br />
   *  Klasse oRecipient<br />
   *  Implementiert das Dom�nenobjekt, das die Empf�nger der Konfiguration h�lt.<br />
   *  <br />
   *  Christian Sch�fer<br />
   *  Version 0.1, 03.06.2005<br />
   */
   class oRecipient extends abstractObject
   {
      var $__Name;
      var $__Adresse;


      function oRecipient(){
         $this->__Name = (string)'';
         $this->__Adresse = (string)'';
       // end function
      }

    // end class
   }
?>
