<?php
   import('modules::kontakt4::biz','abstractObject');


   /**
   *  Package modules::kontakt2::biz<br />
   *  Klasse oFormData<br />
   *  Implementiert das Dom�nenobjekt FormData, das alle Daten des Formulars h�lt.<br />
   *  Dient als Schnittstelleobjekt zwischen pres und biz.<br />
   *  <br />
   *  Christian Sch�fer<br />
   *  Version 0.1, 03.06.2006<br />
   */
   class oFormData extends abstractObject
   {
      var $__RecipientID;
      var $__SenderName;
      var $__SenderEMail;
      var $__Subject;
      var $__Text;


      function oFormData(){

         $this->__RecipientID = (string)'';
         $this->__SenderName = (string)'';
         $this->__SenderEMail = (string)'';
         $this->__Subject = (string)'';
         $this->__Text = (string)'';

       // end function
      }

    // end class
   }
?>
