<?php
   import('tools::variablen','variablenHandler');


   /**
   *  @package modules::schwarzesbrett::pres::documentcontroller::pager
   *  @module pager_v1_controller
   *
   *  Implementiert den DocumentController f�r den PagerManager. Einfacher Pager mit Anzeige von<br />
   *  Seitenzahlen.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 06.08.2006<br />
   *  Version 0.2, 26.11.2006 (Pager gibt einen Leer-String zur�ck, falls keine Seiten vorhanden)<br />
   *  Version 0.3, 03.01.2007 (PageController V2 ready)<br />
   *  Version 0.4, 11.03.2007 (Komplett auf PageController V2 migriert)<br />
   */
   class pager_v1_controller extends baseController
   {

      function pager_v1_controller(){
      }


      function transformContent(){

         // LOCALS f�llen
         $this->_LOCALS = variablenHandler::registerLocal(array($this->__Attributes['Config']['ParameterCountName'] => $this->__Attributes['Config']['EntriesPerPage']));


         // Puffer initialisieren
         $Buffer = (string)'';

         for($i = 0; $i < count($this->__Attributes['Pages']); $i++){

            if($this->__Attributes['Pages'][$i]->get('isSelected') == true){
               $Template = &$this->__getTemplate('Page_Selected');
             // end if
            }
            else{
               $Template = &$this->__getTemplate('Page');
             // end else
            }

            // Pager zusammenbauen
            $Template->setPlaceHolder('Link',$this->__Attributes['Pages'][$i]->get('Link'));
            $Template->setPlaceHolder('Seite',$this->__Attributes['Pages'][$i]->get('Page'));
            $Buffer .= $Template->transform();

          // end for
         }

         // Puffer in Seite einsetzen
         $this->setPlaceHolder('Inhalt',$Buffer);

       // end function
      }

    // end class
   }
?>