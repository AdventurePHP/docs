<?php
   class guestbookInput extends FrontcontrollerInput
   {
    // end class
   }
?>