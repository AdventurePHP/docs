<?php
   class kontakt_controller extends baseController
   {

      function transformContent(){

         $Form = &$this->__getForm('Formular');

         if($Form->get('isSent') == true && $Form->get('isValid') == true){
            header('Location: /Seite/Danke');
          // end if
         }

         $this->setPlaceHolder('Content',$Form->transformForm());

       // end function
      }

    // end class
   }
?>