<?php
   import('core::session','sessionManager');
   import('tools::variablen','variablenHandler');


   class genericfielnametest_v1_controller extends baseController
   {

      var $__oSessMgr = null;
      var $_LOCALS = array();
      var $__FieldMap;


      function genericfielnametest_v1_controller(){

         $this->__oSessMgr = new sessionManager('tools::form::taglib');
         $this->__FieldMap = $this->__oSessMgr->loadSessionData('GenericFormFieldMap');

       // end function
      }


      function transformContent(){

         $Form__GenericFieldNameTest = &$this->__getForm('GenericFieldNameTest');

         $Username = &$Form__GenericFieldNameTest->getFormElementByName($this->__FieldMap['Username']);
         $Password = &$Form__GenericFieldNameTest->getFormElementByName($this->__FieldMap['Password']);

         $this->setPlaceHolder('GenericFieldNameTest',$Form__GenericFieldNameTest->transformForm());

       // end function
      }

    // end class
   }
?>