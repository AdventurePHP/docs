<?php
   import('tools::link','linkHandler');
   import('tools::link','frontcontrollerLinkHandler');
   import('tools::variablen','variablenHandler');


   /**
   *  @package sites::demosite::pres::documentcontroller
   *  @module website_v1_controller
   *
   *  Implementiert den DocumentController f�r das Design 'website.html'.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 09.04.2007<br />
   */
   class website_v1_controller extends baseController
   {

      /**
      *  @private
      *  H�lt lokal verwendete Variablen.
      */
      var $_LOCALS;


      /**
      *  @module website_v1_controller
      *  @public
      *
      *  Konstruktor der Klasse. Initialisiert Member-Variablen.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 09.04.2007<br />
      */
      function website_v1_controller(){
         $this->_LOCALS = variablenHandler::registerLocal(array('Seite' => 'Startseite'));
       // end function
      }


      /**
      *  @module transformContent
      *  @public
      *
      *  Implementiert die abstrakte Methode "transformContent".<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 09.04.2007<br />
      *  Version 0.2, 14.04.2007 (Link um Parameter erweitert um Drucken von Anwendungen zu erlauben)<br />
      *  Version 0.3, 06.05.2007 (Meta-Angaben erg�nzt)<br />
      *  Version 0.4, 21.05.2007 (Ausgabe der URL in den Meta-Angaben verbessert (volle Domain))<br />
      *  Version 0.5, 27.05.2007 (Drucken-Link ohne JAVA-Script implementiert)<br />
      */
      function transformContent(){

         // Meta-Angaben
         $this->setPlaceHolder('URI','http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);
         $this->setPlaceHolder('Date',date('Y-m-d H:i:s'));

         // Druck-Link
         $PrintParams = array_merge($_REQUEST,array('perspective' => 'print'));
         $Link = linkHandler::generateLink(APPS__URL_PATH,$PrintParams);

         $this->setPlaceHolder('PrintLink',$Link);

       // end function
      }

    // end class
   }
?>