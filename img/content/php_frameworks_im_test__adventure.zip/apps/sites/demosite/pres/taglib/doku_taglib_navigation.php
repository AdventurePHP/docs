<?php
   /**
   *  @package sites::demosite::pres::taglib
   *  @module doku_taglib_navigation
   *
   *  Implementiert die Tag-Library f�r die Navigation �ber der Dokumentation.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 13.07.2007<br />
   */
   class doku_taglib_navigation extends Document
   {

      /**
      *  @private
      *  Liste mit Dokumentations-Seiten.
      */
      var $__DokuSites = array();


      /**
      *  @private
      *  LOkal verwendete Variablen.
      */
      var $_LOCALS = array();


      /**
      *  @module doku_taglib_navigation()
      *  @public
      *
      *  Konstruktor der Klasse. Initialisiert die Liste der Doku-Seiten.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 13.07.2007<br />
      *  Version 0.2, 14.07.2007 (Weitere Seiten hinzugef�gt)<br />
      *  Version 0.3, 12.08.2007 (FAQs zur Navi hinzugef�gt)<br />
      */
      function doku_taglib_navigation(){

         // Variablen lokal registrieren
         $this->_LOCALS = variablenHandler::registerLocal(array('Seite' => 'Startseite'));


         // Seiten konfigurieren
         $this->__DokuSites[] = 'Einfuehrung ';
         $this->__DokuSites[] = 'Literatur';
         $this->__DokuSites[] = 'Grundlagen';
         $this->__DokuSites[] = 'HalloWelt';
         $this->__DokuSites[] = 'Klassen';
         $this->__DokuSites[] = 'Templates';
         $this->__DokuSites[] = 'TagLibTags';
         $this->__DokuSites[] = 'Controller';
         $this->__DokuSites[] = 'Konfiguration';
         $this->__DokuSites[] = 'Benchmark';
         $this->__DokuSites[] = 'Formulare';
         $this->__DokuSites[] = 'Links';
         $this->__DokuSites[] = 'Frontcontroller';
         $this->__DokuSites[] = 'KomponentenUndTools';
         $this->__DokuSites[] = 'KomponentenUndTools2';
         $this->__DokuSites[] = 'KomponentenUndTools3';
         $this->__DokuSites[] = 'FAQs';

       // end function
      }


      /**
      *  @module transform()
      *  @public
      *
      *  Implementiert die Interface-Methode "transform()", mit dem ein Objekt in HTML transformiert wird.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 13.07.2007<br />
      */
      function transform(){

         // Aktuelle Seite deklarieren
         $Page = $this->_LOCALS['Seite'];


         // Vorherige Seite deklarieren
         $PreviousPage = $this->__getNeighborPageName($Page);


         // N�chste Seite deklarieren
         $NextPage = $this->__getNeighborPageName($Page,'next');


         // R�ckgabe-Puffer deklarieren
         $Buffer = (string)'';


         // Zur�ck-Bl�ttern anzeigen
         $Buffer .= '<strong>&laquo;</strong>';

         if($PreviousPage != null){
            $Buffer .= '<a href="./?Seite='.$PreviousPage.'" title="Vorherige Seite">Vorherige Seite</a>';

          // end if
         }
         else{
            $Buffer .= '<font style="color: gray;">Vorherige Seite</font>';

          // end else
         }


         // �bersicht anzeigen
         $Buffer .= ' | <a href="./?Seite=Startseite" title="Startseite">Startseite</a> | ';


         // N�chste Seite anzeigen
         if($NextPage != null){
            $Buffer .= '<a href="./?Seite='.$NextPage.'" title="N&auml;chste Seite">N&auml;chste Seite</a>';

          // end if
         }
         else{
            $Buffer .= '<font style="color: gray;">N&auml;chste Seite</font>';

          // end else
         }

         $Buffer .= ' <strong>&raquo;</strong>';


         // Puffer zur�ckgeben
         return $Buffer;

       // end function
      }


      /**
      *  @module transform()
      *  @private
      *
      *  Gibt die Namen der Vorg�nger- und Nachfolger-Seite aus.<br />
      *
      *  @param string $CurrentPage; Name der aktuellen Seite
      *  @param string $Type; Typ der R�ckgabe (previous|next)
      *  @return string $PageName; Name der gew�nschten Nachbar-Seite
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 13.07.2007<br />
      */
      function __getNeighborPageName($CurrentPage,$Type = 'previous'){

         // Offset deklarieren
         $Offset = 0;

         // Aktuellen Offset suchen
         for($i = 0; $i < count($this->__DokuSites); $i++){

            // Pr�fen, ob Seite enthalten ist
            if(strtolower($this->__DokuSites[$i]) == strtolower($CurrentPage)){
               $Offset = $i;
             // end if
            }

          // end for
         }


         // Vorherigen Offset zur�ckgeben
         if($Type == 'previous'){

            if(isset($this->__DokuSites[$Offset - 1])){
               return $this->__DokuSites[$Offset - 1];
             // end if
            }

          // end if
         }


         // N�chsten Offset zur�ckgeben
         if($Type == 'next'){

            if(isset($this->__DokuSites[$Offset + 1])){
               return $this->__DokuSites[$Offset + 1];
             // end if
            }

          // end if
         }


         // null zur�ckgeben
         return null;

       // end function
      }

    // end class
   }
?>