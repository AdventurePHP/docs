<?php
   import('tools::form::taglib','form_taglib_text');
   import('core::session','sessionManager');


   class form_taglib_gentext extends form_taglib_text
   {

      var $__oSessMgr = null;


      function form_taglib_gentext(){
      }


      function onParseTime(){

         // FieldMap aus Session lesen. Attibut "fieldmapname" muss in der Definition gesetzt sein.
         $this->__oSessMgr = new sessionManager('tools::form::taglib');

         if($this->__oSessMgr->loadSessionData('GenericFormFieldMap') == null){
            $FieldMap = array($this->__Attributes['fieldmapname'] => xmlParser::generateUniqID());
            $this->__oSessMgr->saveSessionData('GenericFormFieldMap',$FieldMap);
          // end if
         }
         else{
            $FieldMap = $this->__oSessMgr->loadSessionData('GenericFormFieldMap');
          // end else
         }

         // Feld zur Session hinzuf�gen, falls noch nicht vorhanden
         if(!isset($FieldMap[$this->__Attributes['fieldmapname']])){
            $FieldMap = array_merge($FieldMap,array($this->__Attributes['fieldmapname'] => xmlParser::generateUniqID()));
            $this->__oSessMgr->saveSessionData('GenericFormFieldMap',$FieldMap);
          // end if
         }

         // Name setzen
         $this->__Attributes['name'] = $FieldMap[$this->__Attributes['fieldmapname']];

       // end function
      }


      function transform(){
         unset($this->__Attributes['fieldmapname']);
         return parent::transform();
       // end function
      }

    // end class
   }
?>