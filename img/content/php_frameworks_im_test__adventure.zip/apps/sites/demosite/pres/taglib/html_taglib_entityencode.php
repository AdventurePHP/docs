<?php
   import('tools::string','stringAssistant');


   /**
   *  @package sites::demosite::pres::taglib
   *  @module html_taglib_entityencode
   *
   *  Implementiert die Tag-Library f�r das konvertieren von Text in HTML-encoded Characters.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 24.06.2007<br />
   */
   class html_taglib_entityencode extends Document
   {

      function html_taglib_entityencode(){
      }


      /**
      *  @module transform()
      *  @public
      *
      *  Implementiert die Interface-Methode "transform()", mit dem ein Objekt in HTML<br />
      *  transformiert wird.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 24.06.2007<br />
      */
      function transform(){
         return stringAssistant::encodeCharactersToHTML($this->__Content);
       // end function
      }

    // end class
   }
?>