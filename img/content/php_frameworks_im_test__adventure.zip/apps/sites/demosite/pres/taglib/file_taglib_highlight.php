<?php
   /**
   *  @package sites::demosite::pres::taglib
   *  @module file_taglib_highlight
   *
   *  Implementiert die Tag-Library f�r das PHP-Code-Highlightning einer Datei.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 22.05.2007<br />
   */
   class file_taglib_highlight extends Document
   {

      /**
      *  @private
      *  H�lt eine Liste von anzeigbaren Dateien vor.
      */
      var $__Files = array();


      /**
      *  @module file_taglib_highlight()
      *  @public
      *
      *  Konstruktor der Klasse.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 22.05.2007<br />
      *  Version 0.2, 27.05.2007 (Umbenannte Dateien korrigiert)<br />
      *  Version 0.3, 24.06.2007 (Diverse Dateien hinzugef�gt)<br />
      */
      function file_taglib_highlight(){

         // Unterst�tze Dateien deklarieren
         $this->__Files = array(
                                'index.php' => 'index.php',
                                'INIT_demosite.ini' => APPS__PATH.'/config/core/applicationmanager/INIT_'.APPS__NAME.'.ini',
                                'website.html' => APPS__PATH.'/sites/demosite/pres/templates/site.html',
                                'content.html' => APPS__PATH.'/sites/demosite/pres/templates/content.html',
                                'menu.html' => APPS__PATH.'/sites/demosite/pres/templates/menu.html',
                                'kontakt.html' => APPS__PATH.'/modules/kontakt4/pres/templates/kontakt.html',
                                'formular.html' => APPS__PATH.'/modules/kontakt4/pres/templates/formular.html',
                                'meldung.html' => APPS__PATH.'/modules/kontakt4/pres/templates/meldung.html',
                                'kontakt_v4_controller.php' => APPS__PATH.'/modules/kontakt4/pres/documentcontroller/kontakt_v4_controller.php',
                                'contactManager.php' => APPS__PATH.'/modules/kontakt4/biz/contactManager.php',
                                'contactMapper.php' => APPS__PATH.'/modules/kontakt4/data/contactMapper.php',
                                'php_taglib_highlight.php' => APPS__PATH.'/sites/demosite/pres/taglib/php_taglib_highlight.php',
                                'document_taglib_createcontentobject.php' => APPS__PATH.'/tools/html/taglib/document_taglib_createcontentobject.php',
                                'guestbookMapper.php' => APPS__PATH.'/modules/guestbook/data/guestbookMapper.php',
                                'guestbookManager.php' => APPS__PATH.'/modules/guestbook/biz/guestbookManager.php',
                                'display.html' => APPS__PATH.'/modules/guestbook/pres/templates/display.html',
                                'createentry.html' => APPS__PATH.'/modules/guestbook/pres/templates/createentry.html',
                                'guestbook.html' => APPS__PATH.'/modules/guestbook/pres/templates/guestbook.html',
                                'guestbook_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_v1_controller.php',
                                'guestbook_display_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_display_v1_controller.php',
                                'guestbook_createentry_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_createentry_v1_controller.php',
                                'INIT_helloworld.ini' => APPS__PATH.'/config/core/applicationmanager/INIT_helloworld.ini',
                                'helloworld.html' => APPS__PATH.'/sites/helloworld/pres/templates/helloworld.html',
                                'helloworld.php' => 'helloworld.php',
                                'adminlogin.html' => APPS__PATH.'/modules/guestbook/pres/templates/adminlogin.html',
                                'guestbook_adminlogin_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_adminlogin_v1_controller.php',
                                'adminlogin.html' => APPS__PATH.'/modules/guestbook/pres/templates/adminlogin.html',
                                'adminaddcomment.html' => APPS__PATH.'/modules/guestbook/pres/templates/adminaddcomment.html',
                                'guestbook_adminaddcomment_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_adminaddcomment_v1_controller.php',
                                'html_taglib_entityencode.php' => APPS__PATH.'/sites/demosite/pres/taglib/html_taglib_entityencode.php'
                               );
       // end function
      }


      /**
      *  @module transform()
      *  @public
      *
      *  Implementiert die Interface-Methode "transform()", mit dem ein Objekt in HTML transformiert wird.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 22.05.2007<br />
      *  Version 0.2, 26.05.2007 (H�hen-Berechnung angepasst)<br />
      *  Version 0.3, 27.05.2007 (Abfrage auf Vorhandensein der Datei eingebaut)<br />
      */
      function transform(){

         // Datei-Attribute auslesen
         if(!isset($this->__Attributes['name']) || empty($this->__Attributes['name'])){
            return (string)'<center><div class="phpsource" style="width: 795px; height: 30px;"><strong>Attribute "name" is not set or empty!</strong></div></center>';
          // end if
         }

         // Pr�fen, ob Datei eingelesen werden darf
         if(!isset($this->__Files[$this->__Attributes['name']])){
            return (string)'<center><div class="phpsource" style="width: 795px; height: 30px;"><strong>File "'.$this->__Attributes['name'].'" is not allowed to view!</strong></div></center>';
          // end if
         }

         // Datei einlesen
         if(file_exists($this->__Files[$this->__Attributes['name']])){
            $SourceFileContent = file($this->__Files[$this->__Attributes['name']]);
          // end if
         }
         else{
            return (string)'<center><div class="phpsource" style="width: 795px; height: 30px;"><strong>File "'.$this->__Files[$this->__Attributes['name']].'" doesn\'t exist!</strong></div></center>';
          // end else
         }


         // H�he des Div's errechnen
         // 16 px pro Zeile = 8px Buchstabe + 8px Zwischenraum
         $LineCount = count($SourceFileContent);
         $Height = ($LineCount * 8) + ($LineCount - 1) * 8;

         // Minimale H�he definieren
         if($Height < 16){
            $Height = 28;
          // end if
         }

         // Maximale H�he definieren
         if($Height > 500){
            $Height = 500;
          // end if
         }

         // Tag-Ausgabe zusammensetzen zur�ckgeben
         $Buffer = (string)'';
         $Buffer .= '<center>';
         $Buffer .= PHP_EOL;
         $Buffer .= '<div class="phpsource" style="width: 795px; height: '.$Height.'px;">';
         $Buffer .= PHP_EOL;
         $Buffer .= highlight_string(implode('',$SourceFileContent),true);
         $Buffer .= PHP_EOL;
         $Buffer .= '</div>';
         $Buffer .= PHP_EOL;
         $Buffer .= '</center>';

         // Zur�ckgeben
         return $Buffer;

       // end function
      }

    // end class
   }
?>