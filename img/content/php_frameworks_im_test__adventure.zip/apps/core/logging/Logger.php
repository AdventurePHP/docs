<?php
   import('core::singleton','Singleton');


   // flushLogger als Shutdown-Function registrieren
   register_shutdown_function('flushLogger');


   /**
   *  @package core::logging
   *  @module flushLogger()
   *
   *  Wrapper f�r fas Flushen der Log-Entries auf Platte.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 29.03.2007<br />
   */
   function flushLogger(){
      $L = &Singleton::getInstance('Logger');
      $L->flushLogBuffer();
    // end function
   }


   /**
   *  @package core::logging
   *  @module logEntry
   *
   *  Implementiert ein logEntry-Objekt.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 29.03.2007<br />
   */
   class logEntry
   {

      /**
      *  @private
      *  Datum der Meldung.
      */
      var $__Date;


      /**
      *  @private
      *  Uhrzeit der Meldung.
      */
      var $__Time;


      /**
      *  @private
      *  Text der Meldung.
      */
      var $__Message;


      /**
      *  @private
      *  Typ der Meldung.
      */
      var $__Type;


      /**
      *  @module logEntry()
      *  @public
      *
      *  Konstruktor der Klasse. Erstellt ein neues logEntry-Objekt.<br />
      *
      *  @param string $Message; Meldung
      *  @param string $Type; Type der Meldung
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 29.03.2007<br />
      */
      function logEntry($Message,$Type){

         $this->__Date = date('Y-m-d');
         $this->__Time = date('H:i:s');
         $this->__Message = $Message;
         $this->__Type = $Type;

       // end function
      }


      /**
      *  @module toString()
      *  @public
      *
      *  Liefert den Message-String, der f�r Logging und Ausgabe verwendet wird zur�ck.<br />
      *
      *  @return string $Message; Komplette Meldung
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 29.03.2007<br />
      */
      function toString(){
         return '['.$this->__Date.' '.$this->__Time.'] ['.$this->__Type.'] '.$this->__Message;
       // end function
      }

    // end class
   }

   /**
   *  @package core::logging
   *  @module Logger
   *
   *  Implementiert einen generischen Logger f�r das Logging in<br />
   *  Programmteilen und Modulen. Muss Singleton instanziiert werden.<br />
   *  Das Flushen der Inhalte wird zum Ende eines Requests automatisch<br />
   *  erledigt.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 29.03.2007<br />
   */
   class Logger
   {

      /**
      *  @private
      *  Array, dessen Keys die Logfile-Namen und dessen Offset die zugeh�rigen
      *  logEntry-Objekte sind.
      */
      var $__LogEntries;


      /**
      *  @private
      *  Pfad, in den Log-Dateien abgelegt werden sollen.
      */
      var $__LogDir;


      /**
      *  @private
      *  Ordner-Rechte, mit denen Log-Ordner angelegt werden.
      */
      var $__logFolderPermissions = 0777;


      /**
      *  @private
      *  Ordner-Rechte, mit denen Log-Ordner angelegt werden.
      */
      var $__CRLF = PHP_EOL;



      /**
      *  @module Logger()
      *  @public
      *
      *  Konstruktot der Klasse. Initialisiert den LogPath.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 29.03.2007<br />
      *  Version 0.2, 02.04.2007 (Fehler beim Anlegen des Log-Verzeichnisses behoben)<br />
      */
      function Logger(){

         // Log-Pfad ist APPS__LOG_PATH, oder der Document-Root,
         // falls der APPS__LOG_PATH nicht gesetzt ist.
         if(!defined('APPS__LOG_PATH') || !is_dir(APPS__LOG_PATH)){

            // Log-Verzeichnis oberhalb des DOCUMENT_ROOT anlegen, falls nicht existiert
            $LogDir = str_replace('//','/',$_SERVER['DOCUMENT_ROOT'].'/logs');
            if(!is_dir($LogDir)){

               if(!mkdir($LogDir,$this->__logFolderPermissions)){
                  trigger_error('[Logger->Logger()] There\'s no log directory given, and directory "'.$LogDir.'" cannot be created du to permission restrictions! Please check config an specify "APPS__LOG_PATH"!');
                  exit();
                // end if
               }
               else{
                  $this->__LogDir = $LogDir;
                // end else
               }

             // end if
            }

          // end if
         }
         else{

            // Globalen LOG_PATH �bernehmen
            $this->__LogDir = APPS__LOG_PATH;

          // end else
         }

         // Meldungs-Array initialisieren
         $this->__LogEntries = array();

       // end function
      }


      /**
      *  @module logEntry()
      *  @public
      *
      *  Erzeugt einen Log-Eintrag.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 29.03.2007<br />
      */
      function logEntry($LogFileName,$Message,$Type = 'INFO'){
         $this->__LogEntries[$LogFileName][] = new logEntry($Message,$Type);
       // end function
      }


      /**
      *  @module flushLogBuffer()
      *  @public
      *
      *  Leert den Log-Puffer und schreibt die Eintr�ge auf Platte.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 29.03.2007<br />
      */
      function flushLogBuffer(){

         foreach($this->__LogEntries as $LogFileName => $LogEntries){

            // Kompletten Dateinamen generieren
            $LogFileName = $this->__getLogFileName($LogFileName);

            // Kompletten Dateinamen incl. Pfad generieren
            $LogFile = $this->__LogDir.'/'.$LogFileName;

            // Entries auf Platte flushen
            if(count($LogEntries) > 0){

               // Datei zum appenden �ffnen
               $lFH = fopen($LogFile,'a+');

               for($i = 0; $i < count($LogEntries); $i++){
                  fwrite($lFH,$LogEntries[$i]->toString().$this->__CRLF);
                // end for
               }

               // Datei schlie�en
               fclose($lFH);

             // end if
            }

          // end foreach
         }

       // end function
      }


      /**
      *  @module __getLogFileName()
      *  @private
      *
      *  Gibt den Namen einer LogDatei anhand des Body's des Namens zur�ck.<br />
      *  Log-Dateien haben das Format jjjj_mm_dd__{filename}.log.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 29.03.2007<br />
      */
      function __getLogFileName($FileName){
         return date('Y_m_d').'__'.str_replace('-','_',strtolower($FileName)).'.log';
       // end function
      }

    // end class
   }
?>