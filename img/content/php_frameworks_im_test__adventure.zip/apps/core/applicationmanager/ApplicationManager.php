<?php
   /**
   *  @package core::applicationmanager
   *  @file ApplicationManager.php
   *
   *  - Klasse ApplicationManager: Stellt die globale Konfigurationen bereit.<br />
   *  - import()-Funktion um Funktionen und Klassen zu importieren.<br />
   *    Hier gilt der Grundsatz, nur immer die Klassen und<br />
   *    Module zu importieren, die gerade n�tig sind. Nicht die von ab-<br />
   *    abh�ngigen Modulen. Diese werden mit include_once() aus dem<br />
   *    APPS__PATH + Namespace oder einem Benutzer-Pfad geladen.<br />
   *  - printObject()-Funktion um den Inhalt eines �bergebenen Objekts<br />
   *    auszugeben.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 03.12.2005<br />
   *  Version 0.2. 23.04.2006<br />
   *  Version 0.3, 03.03.2007 (Anpassungen beim Laden der Runtime, PHP 5 Support)<br />
   *  Version 0.4, 28.03.2007 (Message Queue und andere Altlasten entfernt)<br />
   */


   /**
   *  @package core::applicationmanager
   *  @module import()
   *
   *  Importiert Klassen und Module aus einem angegebenem Namespace. Ist bei aktiviertem<br />
   *  PHP-5-Support eine Datei mit der Endung ".php5" vorhanden wird diese gezogen. Befindet<br />
   *  sich keine Datei im angegebenen Namespace wird ein Fallback auf die Endung ".php" initiiert<br />
   *  damit nicht alle Dateien, in denen keine Anpassungen f�r PHP 5 vorgenommen werden m�ssen<br />
   *  auf dem Filesystem vorgehalten sein m�ssen.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 03.12.2005<br />
   *  Version 0.2, 14.04.2006<br />
   *  Version 0.3, 14.01.2007 (Propriet�ren Support f�r PHP 5 implementiert)<br />
   *  Version 0.4, 03.03.2007 (Sch�nheitskorrekturen am Code)<br />
   *  Version 0.5, 03.03.2007 (Support f�r den Betrieb unter PHP 4 und PHP 5 hinzugef�gt)<br />
   */
   function import($Namespace,$File,$ActivatePHP5Support = true){

      // Dateinamen zusammenbauen
      $File = APPS__PATH.'/'.str_replace('::','/',$Namespace).'/'.$File;


      // Datei importieren
      if(intval(phpversion()) == 5 && $ActivatePHP5Support == true){

         // Dateiendung anh�ngen
         $ImportFile = $File.'.php5';

         // Datei importieren
         if(!file_exists($ImportFile)){

            // php5-File annehmen
            $ImportFile = $File.'.php';

            if(!file_exists($ImportFile)){
               trigger_error('[import()] The given module ('.$ImportFile.') cannot be loaded!');
               exit();
             // end if
            }
            else{
               include_once($ImportFile);
             // end else
            }

          // end if
         }
         else{
            include_once($ImportFile);
          // end else
         }

       // end if
      }
      else{

         // Dateiendung anh�ngen
         $ImportFile = $File.'.php';

         // Datei importieren
         if(!file_exists($ImportFile)){
            trigger_error('[import()] The given module ('.$ImportFile.') cannot be loaded!');
            exit();
          // end if
         }
         else{
            include_once($ImportFile);
          // end else
         }

       // end else
      }

    // end function
   }


   /**
   *  @package core::applicationmanager
   *  @module printObject()
   *
   *  Erzeugt die print_r()-Ausgabe eines �bergebenen Objekts und gibt diese zur�ck.<br />
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 04.02.3006<br />
   *  Version 0.2, 23.04.2006 (Ausgabe wird nun in einem Puffer �bergeben)<br />
   */
   function printObject($o,$transformhtml = false){

      $buffer = (string)'';
      $buffer .= "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
      $buffer .= "<br />\n";
      $buffer .= "<strong>\n";
      $buffer .= "Output of printObject():\n";
      $buffer .= "</strong>\n";
      $buffer .= "<br />\n";
      $buffer .= "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
      $buffer .= "\n<pre>";

      if($transformhtml == true){
         $buffer .= htmlentities(print_R($o,true));
       // end if
      }
      else{
         $buffer .= print_R($o,true);
       // end else
      }

      $buffer .= "</pre>\n";
      $buffer .= "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
      $buffer .= "<br />\n";
      $buffer .= "<br />\n";

      return $buffer;

    // end function
   }


   /**
   *  @package core::applicationmanager
   *  @module ApplicationManager
   *
   *  Stellt die Runtime des Frameworks dar. Initialisiert die Konfiguration
   *  einer Applikation.
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 03.12.2005<br />
   *  Version 0.2, 14.12.2005<br />
   *  Version 0.3, 23.04.2006<br />
   *  Version 0.4, 06.08.2006 (Message Queue zum Austausch von Daten in verschiedenen Applikations-Bereichen hinzugef�gt)<br />
   *  Version 0.5, 28.03.2007 (Message Queue und andere Altlasten entfernt)<br />
   */
   class ApplicationManager
   {

      /**
      *  @module ApplicationManager()
      *  @public
      *
      *  Konstruktor der Klasse.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 03.12.2005<br />
      *  Version 0.2, 04.03.2007 (Vereinfachung der Abfragen f�r APPS__NAME und APPS__PATH)<br />
      */
      function ApplicationManager(){

         if(!defined('APPS__NAME') || strlen(APPS__NAME) < 1){
            trigger_error('[ApplicationManager->ApplicationManager()] There\'s no application name defined! Please define constant APPS__NAME before calling the ApplicationManager!',E_USER_ERROR);
            exit();
          // end else
         }

         if(!defined('APPS__PATH') || strlen(APPS__PATH) < 1){
            trigger_error('[ApplicationManager->ApplicationManager()] There\'s no application path defined! Please define constant APPS__PATH before calling the ApplicationManager!',E_USER_ERROR);
            exit();
          // end else
         }


         // Konfiguration einlesen
         $this->__initializeApplication();

       // end function
      }


      /**
      *  @module __initializeApplication()
      *  @private
      *
      *  Initialisiert die aktuelle Applikation an Hand der Parameter<br />
      *  APPS__NAME und APPS__PATH, die vor Aufruf des ApplicationManagers<br />
      *  bereits gesetzt worden sein m�ssen. Es werden die f�r die<br />
      *  Implementierung ben�tigten Parameter APPS__CONTEXT, APPS__ENVIRONMENT<br />
      *  und APPS__URL_PATH gesetzt. Die dazu notwendige Konfigurations.<br />
      *  Datei wird unter der Datei<br />
      *  <br />
      *    <APPS__PATH>/config/core/applicationmanager/<INIT_<APPS__NAME>.ini<br />
      *  <br />
      *  erwarten. Die Parameter ohne Sektion erwartet.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 04.03.2007 (Neuimplementierung der Methode)<br />
      */
      function __initializeApplication(){

         // Konfigurations-Datei pr�fen
         $ConfigFile = APPS__PATH.'/config/core/applicationmanager/INIT_'.APPS__NAME.'.ini';

         if(!file_exists($ConfigFile)){
            trigger_error('[ApplicationManager->__initializeApplication()] The config file <strong>'.$ConfigFile.'</strong> cannot be loaded!',E_USER_ERROR);
            exit();
          // end if
         }


         // Konstanten definieren
         foreach(parse_ini_file($ConfigFile) as $ConstantName => $ConstantValue){
            define($ConstantName,$ConstantValue);
          // end foreach
         }

       // end function
      }

    // end class
   }

   // ApplicationManager (Runtime) initialisieren
   $AM = new ApplicationManager();

   // Globalen ErrorHandler importieren
   import('core::errorhandler','errorHandler');
?>