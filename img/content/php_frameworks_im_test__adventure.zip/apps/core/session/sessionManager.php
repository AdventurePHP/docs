<?php
   /**
   *  @package core::session
   *  @module sessionManager
   *
   *  Stellt ein globales Session-Handling bereit.<br />
   *  <br />
   *  Verwendungsbeispiel:
   *     $oSessMgr = new sessionManager('<namespace>');
   *
   *  @author Christian Sch�fer
   *  @version
   *  Version 0.1, 08.03.2006<br />
   *  Version 0.2, 12.04.2006 (M�glichkeit hinzugef�gt die Klasse singleton instanzieren zu k�nnen)<br />
   */
   class sessionManager
   {

      /**
      *  @private
      *  Namespace der aktuellen Instanz.
      */
      var $__Namespace;


      /**
      *  @module sessionManager()
      *  @public
      *
      *  Konstruktor der Klasse.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function sessionManager($Namespace = ''){

         // Namespace setzen
         if($Namespace != ''){
            $this->setNamespace($Namespace);
          // end if
         }

         // Session initialisieren, falls noch nicht vorhanden
         if(!isset($_SESSION[$Namespace])){
            $this->createSession($Namespace);
          // end if
         }

       // end function
      }


      /**
      *  @module setNamespace()
      *  @public
      *
      *  Setzt den Namespace des aktuellen Instanz des sessionManager's.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function setNamespace($Namespace){
         $this->__Namespace = trim($Namespace);
       // end function
      }


      /**
      *  @module createSession()
      *  @public
      *
      *  Erzeugt einen Session-Namespace.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function createSession($Namespace){
         session_register($Namespace);
       // end function
      }


      /**
      *  @module destroySession()
      *  @public
      *
      *  L�scht die Session im angegebenen Namespace.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      *  Version 0.2, 18.07.2006 (Bug behoben, dass nach einem neuen Post die Session wieder g�ltig war (Server w3service.net)!)<br />
      */
      function destroySession($Namespace){

         // Macht Probleme:
         // session_unregister($Namespace);
         // unset($_SESSION[$Namespace]);

         // Funktioniert:
         $_SESSION[$Namespace] = array();

       // end function
      }


      /**
      *  @module loadSessionData()
      *  @public
      *
      *  L�d Benutzer-Daten aus der Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      *  Version 0.2, 15.06.2006 (Sollte ein Element nicht in der Session vorhanden sein, wird nun false statt '' zur�ckgegeben)<br />
      */
      function loadSessionData($Attribute){

         if(isset($_SESSION[$this->__Namespace][$Attribute])){
            return $_SESSION[$this->__Namespace][$Attribute];
          // end if
         }
         else{
            return false;
          // end else
         }

       // end function
      }


      /**
      *  @module loadSessionData()
      *  @public
      *
      *  L�d Benutzer-Daten aus der Session unter Angabe des Namespaces.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      *  Version 0.2, 15.06.2006 (Sollte ein Element nicht in der Session vorhanden sein, wird nun false statt '' zur�ckgegeben)<br />
      */
      function loadSessionDataByNamespace($Namespace,$Attribute){

         if(isset($_SESSION[$Namespace][$Attribute])){
            return $_SESSION[$Namespace][$Attribute];
          // end if
         }
         else{
            return false;
          // end else
         }

       // end function
      }


      /**
      *  @module saveSessionData()
      *  @public
      *
      *  Speichert Benutzer-Daten in die Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function saveSessionData($Attribute,$Value){
         $_SESSION[$this->__Namespace][$Attribute] = $Value;
       // end function
      }


      /**
      *  @module saveSessionData()
      *  @public
      *
      *  Speichert Benutzer-Daten in die Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function saveSessionDataByNamespace($Namespace,$Attribute,$Value){
         $_SESSION[$Namespace][$Attribute] = $Value;
       // end function
      }


      /**
      *  @module deleteSessionData()
      *  @public
      *
      *  L�scht Benutzer-Daten in die Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function deleteSessionData($Attribute){
         unset($_SESSION[$this->__Namespace][$Attribute]);
       // end function
      }


      /**
      *  @module deleteSessionData()
      *  @public
      *
      *  L�scht Benutzer-Daten in die Session.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function deleteSessionDataByNamespace($Namespace,$Attribute){
         unset($_SESSION[$Namespace][$Attribute]);
       // end function
      }


      /**
      *  @module getSessionID()
      *  @public
      *
      *  Gibt die aktuelle Session-ID zur�ck.<br />
      *
      *  @author Christian Sch�fer
      *  @version
      *  Version 0.1, 08.03.2006<br />
      */
      function getSessionID(){
         return session_id();
       // end function
      }

    // end class
   }
?>