INSTALLATION
~~~~~~~~~~~~

Um die Beispiel-Applikation des Frameworks ausf�hren zu k�nnen muss ein Webserver mit PHP
Version 4.4.x oder h�her installiert sein. Ist noch kein Webserver installiert kann das
bereits vorkonfigurierte Webserver-Paket XAMPP unter 

	http://www.apachefriends.org/de/xampp-windows.html

heruntergeladen und entpackt werden. Das mitgelieferte Paket muss daraufhin in den Document-
Root des Webservers, oder in den Document-Root eines lokalen VHOSTs entpackt werden, damit
das URL-Rewriting funktioniert. Anschlie�end kann die Beispiel-Applikation (Dokumentation
des Frameworks, das auch online Verf�gbar ist) im Browser aufgerufen werden.

Sollten Probleme bei der Installation auftreten, so wenden Sie sich bitte �ber das 
Kontakt-Formular unter http://www.adventure-php-framework.org/Seite/Kontakt an mich, oder
verfassen Sie einen Thread im PHPFriends-Forum unter http://www.phpfriend.de/forum/.