<?php
   // Pfad zum Applikations-Verzeichnis angeben
   define('APPS__PATH','./apps');
   define('APPS__NAME','helloworld');

   // ApplicationManager einbinden
   require_once(APPS__PATH.'/core/applicationmanager/ApplicationManager.php');

   // Page-Controller einbinden
   import('core::pagecontroller','pagecontroller');

   // Webseite erzeugen und ausgeben
   $Page = new Page('helloworld');
   $Page->loadDesign('sites::helloworld','pres/templates/helloworld');
   echo $Page->transform();
?>