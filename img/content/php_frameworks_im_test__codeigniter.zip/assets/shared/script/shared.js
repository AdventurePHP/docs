/**
 * Shared JS File
 *
 * You can code here a script shared by all themes.
 * As an example an AJAX library.
 */