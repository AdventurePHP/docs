<?php
   require_once(dirname(__FILE__) . DS . 'widget_helper.php');

   class PHPHighlightWidgetHelper extends WidgetHelper
   {

      /**
      *  Tag definieren
      */
      var $tag = array('php:highlight');


      function tag_php_highlight($attr,$inner_html){

         //echo '<pre>'.print_r($attr,true).'</pre>';

         // Quelltext highlighten
         // - Zeilenumbr�che am Anfang entfernen
         // - Leerzeichen und Zeilenumbr�che am Ende entfernen
         // - Leerzeichen und Zeilenumbr�che um den kompletten Text entfernen
         $HighlightedContent = highlight_string(trim('<?php'.ltrim(rtrim($inner_html),"\x0A..\x0D").' ?>'),true);

         // PHP-Anfangstag ersetzen
         $HighlightedContent = str_replace('<font color="#007700">&lt;?</font>','',$HighlightedContent);
         $HighlightedContent = str_replace('<font color="#0000BB">&lt;?php&nbsp;','<font color="#0000BB">',$HighlightedContent);
         $HighlightedContent = str_replace('<font color="#0000BB">php','<font color="#0000BB">',$HighlightedContent);
         $HighlightedContent = str_replace('<font color="#0000BB">&nbsp;</font>','',$HighlightedContent);

         // PHP-Endtag ersetzen
         $HighlightedContent = str_replace('<font color="#0000BB">?&gt;</font>','',$HighlightedContent);

         // Code im DIV zur�ckgeben
         return '<div class="phpcode">'.$HighlightedContent.'</div>';

       // end function
      }

    // end class
   }
?>