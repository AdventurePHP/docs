<?php
/**
 * HighlightWidget Helper
 *
 * Highlights some expression found in a html text.
 *
 * Example:
 * In style declaration:
 *         .high { color: yellow; }
 * In view:
 * <h:span class="high" search="/I'm \w+/">
 *         Hi, I'm john. What's your name?
 * </h:h>
 *
 * Will output the html:
 * Hi, <span class="high">I'm john</span>. What's your name?
 *
 * @author RosSoft
 * @version 0.1
 * @license MIT
 *
 */
require_once(dirname(__FILE__) . DS . 'widget_helper.php');
class HighlightWidgetHelper extends WidgetHelper
{
    //main tags name => array subtags
    var $tag=array('h:div','h:span');

    function tag_h_div($attr,$inner_html)
    {
        return $this->replace($attr,$inner_html,'div');
    }

    function tag_h_span($attr,$inner_html)
    {
        return $this->replace($attr,$inner_html,'span');
    }

    function replace($attr,$inner_html,$type){

        $class=@$attr['class'];
        $expression=@$attr['search'];
        return preg_replace($expression,"<".$type." class=\"".$class."\">I'm \\1</".$type.">",$inner_html);
        //return preg_replace($expression,"<$type class=\"$class\">" . '/' . "</$type>",$inner_html);
    }

}
?>