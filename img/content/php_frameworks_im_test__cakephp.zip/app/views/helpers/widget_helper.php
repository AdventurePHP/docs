<?php
/**
 * Widget Helper
 *
 * Parses custom html tags like
 * <mytag:mytag1 attr1="value1" attr2="value2">some html</mytag:mytag1>
 * (This class must be extended)
 *
 * @author RosSoft
 * @version 0.1
 * @license MIT
 *
 * The filename is widget_helper.php because you must
 * overload it, not use directly.
 *
 */

class WidgetHelper extends Helper
{
    var $_library; //static array of widgets instances

    //main tag names => array subtags
    var $tag=array();
    var $_data=array();

    var $helpers=array('Util');

    function __construct()
    {
        static $library=array();  //for php4 compat
           $this->_library=& $library;

           $this->_library[]=& $this; //add current instance
           //echo '<br /><pre>'.print_r($this->_library);

        if (!in_array('Util',$this->helpers))
        {
            array_push($this->helpers,'Util');
        }
    }

    /**
     * afterRender Callback
     */
    function afterRender()
    {
        static $once=true;
        if (! $once) return;
        $once=false;

        $html=@ob_get_clean();
        ob_start();
        $matches=array();

        //echo '<pre>'.print_r($this->_library,true).'</pre>';

        preg_match_all("/(<(\w+:\w+)([^>]*)>(.*?)<\/\\2>)|(<(\w+:\w+)([^>]*)\/>())/is", $html, $matches,PREG_SET_ORDER);
        foreach ($matches as $match)
        {

            if (isset($match[6]))
            {
                $tagname=$match[6];
                $attributes=$match[7];
                $inner_html=$match[8];
            }
            else
            {
                $tagname=$match[2];
                $attributes=$match[3];
                $inner_html=$match[4];
            }
            $outer_html=$match[0];
            foreach ($this->_library as $widget)
            {
                foreach ($widget->tag as $tag=>$subtags)
                {
                    if (is_numeric($tag))
                    {
                        $tag=$subtags;
                        $subtags=array();
                    }
                    if ($tag==$tagname)
                    {
                        $html=$widget->_process_tag($html, $tag, $outer_html,$inner_html,$attributes,$subtags);
                    }
                }
            }
        }
        echo $html;
    }

    /**
     * Bind data to the widget
     *
     * @param string $name Name of the data
     * @param mixed $data The data
     */
    function bind($name, $data)
    {
        $this->_data[$name] = $data;
    }

    /**
     * Process one tag
     * @param string $content The complete document
     * @param string $tag_html One tag
     */
    function _process_tag($html, $tag_id,$outer_html,$inner_html,$attributes,$subtags)
    {
        // Parse tag
        $attributes= $this->_parse_attributes($attributes);

        $this->_tag_id=$tag_id;
        $this->_tag_inner_html=$inner_html;
        $this->_tag_subtags=$subtags;

        $method_name='tag_' . str_replace(':','_',$tag_id);
        $out=$this->$method_name($attributes,$inner_html);
        if ($out!==false)
        {
            return str_replace($outer_html,$out, $html);
        }
        else
        {
            //show the error through html entities
            return str_replace($outer_html,h($outer_html), $html);
        }
    }

    function _get_bound($name)
    {
        return $this->_data[$name];
    }

    function _get_field_value($fieldName)
    {
        return $this->Util->retrieve_value($fieldName);
    }

    function _get_view_value($var_name)
    {
        return $this->view->_viewVars[$var_name];
    }

    function _process_subtags($params=array(),$html=null)
    {
        if ($html===null)
        {
            $html=$this->_tag_inner_html;
        }
        foreach ($this->_tag_subtags as $subtag)
        {
            preg_match_all("/(\<$subtag([^>]*)\>(.*?)\<\/$subtag\>)|(\<$subtag([^>]*)\/\>())/is", $html, $matches,PREG_SET_ORDER);
            for ($i=0; $i < count($matches); $i++)
            {
                $outer_html= $matches[$i][0];
                if (isset($matches[$i][5]))
                {
                    $attributes=$matches[$i][5];
                }
                else
                {
                    $attributes=$matches[$i][2];
                }
                $attributes=$this->_parse_attributes($attributes);

                $inner_html= $matches[$i][3];
                $method_name='subtag_' . str_replace(':','_',$subtag);
                $out=$this->$method_name($attributes,$inner_html,$params);
                if ($out!==false)
                {
                    $html= str_replace($outer_html,  $out, $html);
                }
                else
                {
                    //show the error through html entities
                    $html= str_replace($outer_html,  h($out), $html);
                }
            }

        }
        return $html;
    }

    function _parse_attributes($html)
    {
        $matches=array();
        $attributes=array();
        preg_match_all('/(\w+)\s*=\s*"([^"]*)"/is', $html, $matches,PREG_SET_ORDER);
        foreach ($matches as $attr)
        {
            $attributes[low($attr[1])]=$attr[2];
        }
        return $attributes;
    }

}
?>