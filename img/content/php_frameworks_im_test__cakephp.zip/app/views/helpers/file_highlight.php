<?php
   // APPS__PATH definieren
   define('APPS__PATH','E:/Apache2/htdocs/apps');


   // APPS__NAME  definieren
   define('APPS__NAME','demosite');


   // WidgetHelper einbinden
   require_once(dirname(__FILE__) . DS . 'widget_helper.php');


   class FileHighlightHelper  extends WidgetHelper
   {

      /**
      *  Tag definieren
      */
      var $tag = array('file:highlight');


      /**
      *  Array mit den aufgelisteten Dateien
      */
      var $__Files = array();


      function __fillFilesArray(){

         // Unterst�tze Dateien deklarieren
         $this->__Files = array(
                                'index.php' => 'index.php',
                                'INIT_demosite.ini' => APPS__PATH.'/config/core/applicationmanager/INIT_'.APPS__NAME.'.ini',
                                'website.html' => APPS__PATH.'/sites/demosite/pres/templates/site.html',
                                'content.html' => APPS__PATH.'/sites/demosite/pres/templates/content.html',
                                'menu.html' => APPS__PATH.'/sites/demosite/pres/templates/menu.html',
                                'kontakt.html' => APPS__PATH.'/modules/kontakt4/pres/templates/kontakt.html',
                                'formular.html' => APPS__PATH.'/modules/kontakt4/pres/templates/formular.html',
                                'meldung.html' => APPS__PATH.'/modules/kontakt4/pres/templates/meldung.html',
                                'kontakt_v4_controller.php' => APPS__PATH.'/modules/kontakt4/pres/documentcontroller/kontakt_v4_controller.php',
                                'contactManager.php' => APPS__PATH.'/modules/kontakt4/biz/contactManager.php',
                                'contactMapper.php' => APPS__PATH.'/modules/kontakt4/data/contactMapper.php',
                                'php_taglib_highlight.php' => APPS__PATH.'/sites/demosite/pres/taglib/php_taglib_highlight.php',
                                'document_taglib_createcontentobject.php' => APPS__PATH.'/tools/html/taglib/document_taglib_createcontentobject.php',
                                'guestbookMapper.php' => APPS__PATH.'/modules/guestbook/data/guestbookMapper.php',
                                'guestbookManager.php' => APPS__PATH.'/modules/guestbook/biz/guestbookManager.php',
                                'display.html' => APPS__PATH.'/modules/guestbook/pres/templates/display.html',
                                'createentry.html' => APPS__PATH.'/modules/guestbook/pres/templates/createentry.html',
                                'guestbook.html' => APPS__PATH.'/modules/guestbook/pres/templates/guestbook.html',
                                'guestbook_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_v1_controller.php',
                                'guestbook_display_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_display_v1_controller.php',
                                'guestbook_createentry_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_createentry_v1_controller.php',
                                'INIT_helloworld.ini' => APPS__PATH.'/config/core/applicationmanager/INIT_helloworld.ini',
                                'helloworld.html' => APPS__PATH.'/sites/helloworld/pres/templates/helloworld.html',
                                'helloworld.php' => 'helloworld.php',
                                'adminlogin.html' => APPS__PATH.'/modules/guestbook/pres/templates/adminlogin.html',
                                'guestbook_adminlogin_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_adminlogin_v1_controller.php',
                                'adminlogin.html' => APPS__PATH.'/modules/guestbook/pres/templates/adminlogin.html',
                                'adminaddcomment.html' => APPS__PATH.'/modules/guestbook/pres/templates/adminaddcomment.html',
                                'guestbook_adminaddcomment_v1_controller.php' => APPS__PATH.'/modules/guestbook/pres/documentcontroller/guestbook_adminaddcomment_v1_controller.php',
                                'html_taglib_entityencode.php' => APPS__PATH.'/sites/demosite/pres/taglib/html_taglib_entityencode.php'
                               );
       // end function
      }


      /**
      *  Rendering-Methode f�r den Tag
      */
      function tag_file_highlight($Attributes){

         // Array f�llen
         $this->__fillFilesArray();


         // Datei-Attribute auslesen
         if(!isset($Attributes['name']) || empty($Attributes['name'])){
            return (string)'<center><div class="phpsource" style="width: 795px; height: 30px;"><strong>Attribute "name" is not set or empty!</strong></div></center>';
          // end if
         }

         // Pr�fen, ob Datei eingelesen werden darf
         if(!isset($this->__Files[$Attributes['name']])){
            return (string)'<center><div class="phpsource" style="width: 795px; height: 30px;"><strong>File "'.$this->__Attributes['name'].'" is not allowed to view!</strong></div></center>';
          // end if
         }

         // Datei einlesen
         if(file_exists($this->__Files[$Attributes['name']])){
            $SourceFileContent = file($this->__Files[$Attributes['name']]);
          // end if
         }
         else{
            return (string)'<center><div class="phpsource" style="width: 795px; height: 30px;"><strong>File "'.$this->__Files[$Attributes['name']].'" doesn\'t exist!</strong></div></center>';
          // end else
         }


         // H�he des Div's errechnen
         // 16 px pro Zeile = 8px Buchstabe + 8px Zwischenraum
         $LineCount = count($SourceFileContent);
         $Height = ($LineCount * 8) + ($LineCount - 1) * 8;

         // Minimale H�he definieren
         if($Height < 16){
            $Height = 28;
          // end if
         }

         // Maximale H�he definieren
         if($Height > 500){
            $Height = 500;
          // end if
         }

         // Tag-Ausgabe zusammensetzen zur�ckgeben
         $Buffer = (string)'';
         $Buffer .= '<center>';
         $Buffer .= PHP_EOL;
         $Buffer .= '<div class="phpsource" style="width: 795px; height: '.$Height.'px;">';
         $Buffer .= PHP_EOL;
         $Buffer .= highlight_string(implode('',$SourceFileContent),true);
         $Buffer .= PHP_EOL;
         $Buffer .= '</div>';
         $Buffer .= PHP_EOL;
         $Buffer .= '</center>';

         // Zur�ckgeben
         return $Buffer;

       // end function
      }

    // end class
   }
?>