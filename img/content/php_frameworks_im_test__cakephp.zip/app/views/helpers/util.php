<?php
   class UtilHelper extends Helper {
   }
?>