<?php
   require_once(dirname(__FILE__) . DS . 'widget_helper.php');

   class DokuNavigationHelper extends WidgetHelper
   {

      /**
      *  Tag definieren
      */
      var $tag = array('doku:navigation');


      /**
      *  Array mit den aufgelisteten Seiten
      */
      var $__DokuSites = array();


      /**
      *  F�llen des Arrays wird in eine andere Methode verlagert, da es im Konstruktor
      *  zu einem Referenz-Fehler in der Elternklasse kommt.
      */
      function __fillSitesArray(){

         // Seiten konfigurieren
         $this->__DokuSites[] = 'Einfuehrung ';
         $this->__DokuSites[] = 'Literatur';
         $this->__DokuSites[] = 'Grundlagen';
         $this->__DokuSites[] = 'HalloWelt';
         $this->__DokuSites[] = 'Klassen';
         $this->__DokuSites[] = 'Templates';
         $this->__DokuSites[] = 'TagLibTags';
         $this->__DokuSites[] = 'Controller';
         $this->__DokuSites[] = 'Konfiguration';
         $this->__DokuSites[] = 'Benchmark';
         $this->__DokuSites[] = 'Formulare';
         $this->__DokuSites[] = 'Links';
         $this->__DokuSites[] = 'Frontcontroller';
         $this->__DokuSites[] = 'KomponentenUndTools';
         $this->__DokuSites[] = 'KomponentenUndTools2';
         $this->__DokuSites[] = 'KomponentenUndTools3';

       // end function
      }


      /**
      *  Rendering-Methode f�r den Tag
      */
      function tag_doku_navigation($Attributes){

         // Array f�llen
         $this->__fillSitesArray();


         // Aktuelle Seite deklarieren
         $Page = $this->action;


         // Vorherige Seite deklarieren
         $PreviousPage = $this->__getNeighborPageName($Page);


         // N�chste Seite deklarieren
         $NextPage = $this->__getNeighborPageName($Page,'next');


         // R�ckgabe-Puffer deklarieren
         $Buffer = (string)'';


         // Zur�ck-Bl�ttern anzeigen
         $Buffer .= '<strong>&laquo;</strong>';

         if($PreviousPage != null){
            $Buffer .= '<a href="/Seite/'.$PreviousPage.'" title="Vorherige Seite">Vorherige Seite</a>';

          // end if
         }
         else{
            $Buffer .= '<font style="color: gray;">Vorherige Seite</font>';

          // end else
         }


         // �bersicht anzeigen
         $Buffer .= ' | <a href="/Seite/Startseite" title="Startseite">Startseite</a> | ';


         // N�chste Seite anzeigen
         if($NextPage != null){
            $Buffer .= '<a href="/Seite/'.$NextPage.'" title="N&auml;chste Seite">N&auml;chste Seite</a>';

          // end if
         }
         else{
            $Buffer .= '<font style="color: gray;">N&auml;chste Seite</font>';

          // end else
         }

         $Buffer .= ' <strong>&raquo;</strong>';


         // Puffer zur�ckgeben
         return $Buffer;

       // end function
      }


      function __getNeighborPageName($CurrentPage,$Type = 'previous'){

         // Offset deklarieren
         $Offset = 0;

         // Aktuellen Offset suchen
         for($i = 0; $i < count($this->__DokuSites); $i++){

            // Pr�fen, ob Seite enthalten ist
            if(strtolower($this->__DokuSites[$i]) == strtolower($CurrentPage)){
               $Offset = $i;
             // end if
            }

          // end for
         }


         // Vorherigen Offset zur�ckgeben
         if($Type == 'previous'){

            if(isset($this->__DokuSites[$Offset - 1])){
               return $this->__DokuSites[$Offset - 1];
             // end if
            }

          // end if
         }


         // N�chsten Offset zur�ckgeben
         if($Type == 'next'){

            if(isset($this->__DokuSites[$Offset + 1])){
               return $this->__DokuSites[$Offset + 1];
             // end if
            }

          // end if
         }


         // null zur�ckgeben
         return null;

       // end function
      }

    // end class
   }
?>