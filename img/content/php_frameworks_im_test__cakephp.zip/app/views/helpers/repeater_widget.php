<?php
/**
 * RepeaterWidget Helper
 *
 * Repeats the html within the tag <repeater:repeater>HTML</repeater:repeater>
 * that contains the subtags <repeater:key /> and <repeater:value />
 * It replaces the subtags with the key & value from an associative array.
 * You must bind the widget to the array through
 * Example:
 * <?php
 * $array=array('Frodo'=>'Elijah Wood','Aragorn'=>'Viggo Mortensen')
 * $repeaterWidget->bind('cast',$array))?> *
 * <repeater:repeater array='cast'>
 *     <b><repeater:key/>:</b> <repeater:value/>
 *     <br/>
 * </repeater>
 *
 * Will output the html:
 *     <b>Frodo:</b>: Elijah Wood
 *     <br/>
 *     <b>Aragorn:</b>: Viggo Mortensen
 *     <br/>
 *
 * @author RosSoft
 * @version 0.1
 * @license MIT
 *
 * @link http://www.phpit.net/article/create-html-widgets-php/4/
 */
require_once(dirname(__FILE__) . DS . 'widget_helper.php');
class RepeaterWidgetHelper extends WidgetHelper
{
    //main tags name => array subtags
    var $tag=array(
                'repeater:repeater'=>array('repeater:key','repeater:value')
            );

   function tag_repeater_repeater($attr,$inner_html){

        $array=$this->_get_bound($attr['array']);

        // loop through bound array
        $new_html = '';
        foreach ($array as $k=> $v)
        {
            $new_html .= $this->_process_subtags(array('key'=>$k,'value'=>$v));
        }
        return $new_html;
    }

    function subtag_repeater_key($attr,$inner_html,$params)
    {
        return $params['key'];
    }

    function subtag_repeater_value($attr,$inner_html,$params)
    {
        return $params['value'];
    }
}
?>