<?php
class HTMLHelper extends Helper {
}
?>