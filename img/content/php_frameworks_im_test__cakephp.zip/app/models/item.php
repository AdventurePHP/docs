<?php
   class Item extends AppModel
   {
      var $name = 'Item';
   }
?>