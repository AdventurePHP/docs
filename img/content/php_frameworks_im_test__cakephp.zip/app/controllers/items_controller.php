<?php
   class ItemsController extends AppController
   {
      var $name = 'Items';
      var $scaffold;
   }
?>