<?php
   require_once('../../cake/libs/controller/pages_controller.php');

   class SeiteController extends PagesController
   {

      /**
      *  Name des Ordners in dem die View-Templates abgelegt werden.
      */
      var $name = 'demosite';


      /**
      *  Bekanntmachen der Helper
      */
      var $helpers = array('RepeaterWidget','HighlightWidget','PHPHighlightWidget','DokuNavigation','FileHighlight');


      /**
      *  null = keine Models werden verwendet
      */
      var $uses = null;


      function FormularTest(){

         // Ist Formular abgeschickt worden?
         if(!empty($this->data['Contact'])){

            // Merker f�r die Validierung setzen
            $valid = true;

            // Validierung Name
            if(isset($this->data['Contact']['name']) && strlen($this->data['Contact']['name']) > 3){
               $this->set('ContactNameStyle','');
               $this->set('ContactNameErrorMessage','');
            }
            else{
               $this->set('ContactNameErrorMessage',' Bitte geben Sie einen Namen an!');
               $this->set('ContactNameStyle',' border: 2px solid red;');
               $valid = false;
            }

            // Validierung Betreff
            if(isset($this->data['Contact']['subject']) && strlen($this->data['Contact']['subject']) > 3){
               $this->set('ContactSubjectStyle','');
               $this->set('ContactSubjectErrorMessage','');
            }
            else{
               $this->set('ContactSubjectStyle',' border: 2px solid red;');
               $this->set('ContactSubjectErrorMessage',' Bitte geben Sie ein Betreff an!');
               $valid = false;
            }

            // Validierung E-Mail
            if(isset($this->data['Contact']['email']) && ereg("^([a-zA-Z0-9\.\_\-]+)@([a-zA-Z0-9\.\-]+\.[A-Za-z][A-Za-z]+)$",$this->data['Contact']['email']) && strlen($this->data['Contact']['email']) > 3){
               $this->set('ContactEMailStyle','');
               $this->set('ContactEMailErrorMessage','');
            }
            else{
               $this->set('ContactEMailStyle',' border: 2px solid red;');
               $this->set('ContactEMailErrorMessage',' Bitte geben sie eine korrekte E-Mail-Adresse an!');
               $valid = false;
            }


            // Falls Formular valide ist, abschicken
            if($valid == true){

               // E-Mail versenden
               $this->redirect('/Seite/FormularDanke');

             // end if
            }

          // end if
         }
         else{

            // Standard-Werte setzen, da sonst Fehler mit undefined variable geworfen werden
            $this->set('ContactNameStyle','');
            $this->set('ContactEMailStyle','');
            $this->set('ContactSubjectStyle','');
            $this->set('ContactNoteStyle','');
            $this->set('ContactNameErrorMessage','');
            $this->set('ContactEMailErrorMessage','');
            $this->set('ContactSubjectErrorMessage','');

          // end else
         }

       // end function
      }


      function Benchmark(){

         // Erzeugt den Inhalt des Men�s
         //$Menu = $this->renderElement('menu');

         // Inhalt in Menu einsetzen
         //$this->set('menu_for_layout',$Menu);

       // end function
      }


      function Startseite(){

         // extract params
         $Params = func_get_args();

         // set view attributes
         if(!empty($Params[0])){
            $this->set('Param1',$Params[0]);
          // end if
         }
         else{
            $this->set('Param1','empty');
          // end else
         }
         if(!empty($Params[1])){
            $this->set('Param2',$Params[1]);
          // end if
         }
         else{
            $this->set('Param2','empty');
          // end else
         }
         if(!empty($Params[2])){
            $this->set('Param3',$Params[2]);
          // end if
         }
         else{
            $this->set('Param3','empty');
          // end else
         }
         if(!empty($Params[3])){
            $this->set('Param4',$Params[3]);
          // end if
         }
         else{
            $this->set('Param4','empty');
          // end else
         }

       // end function
      }

    // end class
   }
?>