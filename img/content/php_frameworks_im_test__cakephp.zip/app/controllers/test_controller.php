<?php
   class TestController extends AppController {

      var $name = 'Test';

      function TestController(){

         echo '<pre>'.$html.'</pre>';

       // end function
      }

    // end function
   }
?>